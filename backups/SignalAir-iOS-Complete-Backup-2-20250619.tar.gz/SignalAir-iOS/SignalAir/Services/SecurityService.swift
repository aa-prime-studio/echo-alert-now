import Foundation
import CryptoKit
import Security

// MARK: - Crypto Errors
enum CryptoError: Error {
    case noPrivateKey
    case noSessionKey
    case invalidSignature
    case expiredMessage
    case keyGenerationFailed
    case encryptionFailed
    case decryptionFailed
    case keyExchangeFailed
    case keychainError(OSStatus)
    case invalidKeyData
    case messageNumberMismatch
}

// MARK: - Session Key Structure
struct SessionKey {
    let encryptionKey: SymmetricKey
    let hmacKey: SymmetricKey
    var messageNumber: UInt64 = 0
    let createdAt: Date
    
    init(encryptionKey: SymmetricKey, hmacKey: SymmetricKey, messageNumber: UInt64 = 0) {
        self.encryptionKey = encryptionKey
        self.hmacKey = hmacKey
        self.messageNumber = messageNumber
        self.createdAt = Date()
    }
}

// MARK: - Encrypted Message Structure
struct EncryptedMessage: Codable {
    let ciphertext: Data
    let hmac: Data
    let messageNumber: UInt64
    let timestamp: Date
    
    var data: Data {
        get throws {
            return try JSONEncoder().encode(self)
        }
    }
    
    static func decode(from data: Data) throws -> EncryptedMessage {
        return try JSONDecoder().decode(EncryptedMessage.self, from: data)
    }
}

// MARK: - Security Service
class SecurityService: ObservableObject {
    // MARK: - Properties
    private var privateKey: Curve25519.KeyAgreement.PrivateKey?
    private var sessionKeys: [String: SessionKey] = [:]
    private let keyRotationInterval: TimeInterval = 3600 // 1 hour
    private var keyRotationTimer: Timer?
    
    // MARK: - Published State
    @Published var isInitialized: Bool = false
    @Published var activeConnections: Int = 0
    
    // MARK: - Keychain Configuration
    private let keychainService = "com.signalair.crypto"
    private let privateKeyTag = "signalair.privatekey"
    
    // MARK: - Initialization
    init() {
        setupCryptoSystem()
        startKeyRotationTimer()
        print("🔐 SecurityService initialized")
    }
    
    deinit {
        keyRotationTimer?.invalidate()
    }
    
    // MARK: - Public Methods
    
    /// 取得公鑰用於密鑰交換
    func getPublicKey() throws -> Data {
        guard let privateKey = privateKey else {
            throw CryptoError.noPrivateKey
        }
        
        return privateKey.publicKey.rawRepresentation
    }
    
    /// 執行 ECDH 密鑰交換
    func performKeyExchange(with peerPublicKey: Data, peerID: String) throws {
        guard let privateKey = privateKey else {
            throw CryptoError.noPrivateKey
        }
        
        do {
            // 建立對方的公鑰
            let peerKey = try Curve25519.KeyAgreement.PublicKey(rawRepresentation: peerPublicKey)
            
            // 執行 ECDH
            let sharedSecret = try privateKey.sharedSecretFromKeyAgreement(with: peerKey)
            
            // 使用 HKDF 衍生雙密鑰
            let salt = "SignalAir Rescue-v1.0".data(using: .utf8)!
            let info = "\(peerID)-session".data(using: .utf8)!
            
            let keyMaterial = sharedSecret.hkdfDerivedSymmetricKey(
                using: SHA256.self,
                salt: salt,
                sharedInfo: info,
                outputByteCount: 64
            )
            
            // 分割為加密和 HMAC 密鑰
            let rawKey = keyMaterial.withUnsafeBytes { Data($0) }
            let encryptionKey = SymmetricKey(data: rawKey.prefix(32))
            let hmacKey = SymmetricKey(data: rawKey.suffix(32))
            
            // 儲存會話密鑰
            sessionKeys[peerID] = SessionKey(
                encryptionKey: encryptionKey,
                hmacKey: hmacKey
            )
            
            DispatchQueue.main.async {
                self.activeConnections = self.sessionKeys.count
            }
            
            print("✅ Key exchange completed with: \(peerID)")
            
        } catch {
            print("❌ Key exchange failed: \(error)")
            throw CryptoError.keyExchangeFailed
        }
    }
    
    /// 加密訊息
    func encrypt(_ data: Data, for peerID: String) throws -> EncryptedMessage {
        guard var sessionKey = sessionKeys[peerID] else {
            throw CryptoError.noSessionKey
        }
        
        do {
            // AES-GCM 加密
            let sealed = try AES.GCM.seal(data, using: sessionKey.encryptionKey)
            
            guard let ciphertext = sealed.combined else {
                throw CryptoError.encryptionFailed
            }
            
            // HMAC 簽名
            let hmac = HMAC<SHA256>.authenticationCode(
                for: ciphertext,
                using: sessionKey.hmacKey
            )
            
            // 建立加密訊息
            let encryptedMessage = EncryptedMessage(
                ciphertext: ciphertext,
                hmac: Data(hmac),
                messageNumber: sessionKey.messageNumber,
                timestamp: Date()
            )
            
            // 更新密鑰（Forward Secrecy）
            sessionKey = ratchetKey(sessionKey)
            sessionKeys[peerID] = sessionKey
            
            print("🔒 Encrypted message for: \(peerID), size: \(data.count) bytes")
            return encryptedMessage
            
        } catch {
            print("❌ Encryption failed: \(error)")
            throw CryptoError.encryptionFailed
        }
    }
    
    /// 解密訊息
    func decrypt(_ data: Data, from peerID: String) throws -> Data {
        guard var sessionKey = sessionKeys[peerID] else {
            throw CryptoError.noSessionKey
        }
        
        do {
            // 解碼加密訊息
            let encryptedMessage = try EncryptedMessage.decode(from: data)
            
            // 驗證訊息順序（防重放攻擊）
            guard encryptedMessage.messageNumber >= sessionKey.messageNumber else {
                throw CryptoError.messageNumberMismatch
            }
            
            // 驗證 HMAC
            let expectedHMAC = HMAC<SHA256>.authenticationCode(
                for: encryptedMessage.ciphertext,
                using: sessionKey.hmacKey
            )
            
            guard Data(expectedHMAC) == encryptedMessage.hmac else {
                throw CryptoError.invalidSignature
            }
            
            // 解密
            let sealedBox = try AES.GCM.SealedBox(combined: encryptedMessage.ciphertext)
            let plaintext = try AES.GCM.open(sealedBox, using: sessionKey.encryptionKey)
            
            // 更新密鑰（Forward Secrecy）
            sessionKey = ratchetKey(sessionKey)
            sessionKey.messageNumber = encryptedMessage.messageNumber + 1
            sessionKeys[peerID] = sessionKey
            
            print("🔓 Decrypted message from: \(peerID), size: \(plaintext.count) bytes")
            return plaintext
            
        } catch {
            print("❌ Decryption failed: \(error)")
            throw CryptoError.decryptionFailed
        }
    }
    
    /// 移除會話密鑰
    func removeSessionKey(for peerID: String) {
        sessionKeys.removeValue(forKey: peerID)
        DispatchQueue.main.async {
            self.activeConnections = self.sessionKeys.count
        }
        print("🗑️ Removed session key for: \(peerID)")
    }
    
    /// 檢查是否有會話密鑰
    func hasSessionKey(for peerID: String) -> Bool {
        return sessionKeys[peerID] != nil
    }
    
    /// 清除所有會話密鑰
    func clearAllSessionKeys() {
        sessionKeys.removeAll()
        DispatchQueue.main.async {
            self.activeConnections = 0
        }
        print("🧹 Cleared all session keys")
    }
    
    // MARK: - Private Methods
    
    /// 設置加密系統
    private func setupCryptoSystem() {
        do {
            if let savedKey = try loadPrivateKeyFromKeychain() {
                self.privateKey = savedKey
                print("🔑 Loaded existing private key from keychain")
            } else {
                self.privateKey = Curve25519.KeyAgreement.PrivateKey()
                try savePrivateKeyToKeychain(privateKey!)
                print("🆕 Generated new private key and saved to keychain")
            }
            
            DispatchQueue.main.async {
                self.isInitialized = true
            }
            
        } catch {
            print("❌ Failed to setup crypto system: \(error)")
            // 即使失敗也生成臨時密鑰
            self.privateKey = Curve25519.KeyAgreement.PrivateKey()
            DispatchQueue.main.async {
                self.isInitialized = true
            }
        }
    }
    
    /// 密鑰輪轉（Forward Secrecy）
    private func ratchetKey(_ key: SessionKey) -> SessionKey {
        // 使用當前加密密鑰生成新密鑰
        let newKeyMaterial = HMAC<SHA256>.authenticationCode(
            for: "ratchet-\(key.messageNumber)".data(using: .utf8)!,
            using: key.encryptionKey
        )
        
        let newEncryptionKey = SymmetricKey(data: Data(newKeyMaterial.prefix(32)))
        
        return SessionKey(
            encryptionKey: newEncryptionKey,
            hmacKey: key.hmacKey, // HMAC 密鑰保持不變
            messageNumber: key.messageNumber + 1
        )
    }
    
    /// 定期密鑰輪轉
    private func startKeyRotationTimer() {
        keyRotationTimer = Timer.scheduledTimer(withTimeInterval: keyRotationInterval, repeats: true) { _ in
            self.rotateExpiredKeys()
        }
    }
    
    /// 輪轉過期密鑰
    private func rotateExpiredKeys() {
        let now = Date()
        var rotatedCount = 0
        
        for (peerID, key) in sessionKeys {
            if now.timeIntervalSince(key.createdAt) > keyRotationInterval {
                // 生成新的會話密鑰（需要重新密鑰交換）
                sessionKeys.removeValue(forKey: peerID)
                rotatedCount += 1
            }
        }
        
        if rotatedCount > 0 {
            print("🔄 Rotated \(rotatedCount) expired session keys")
            DispatchQueue.main.async {
                self.activeConnections = self.sessionKeys.count
            }
        }
    }
    
    // MARK: - Keychain Operations
    
    /// 儲存私鑰到 Keychain
    private func savePrivateKeyToKeychain(_ key: Curve25519.KeyAgreement.PrivateKey) throws {
        let keyData = key.rawRepresentation
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: privateKeyTag,
            kSecValueData as String: keyData
        ]
        
        // 先刪除舊的
        SecItemDelete(query as CFDictionary)
        
        // 添加新的
        let status = SecItemAdd(query as CFDictionary, nil)
        
        guard status == errSecSuccess else {
            throw CryptoError.keychainError(status)
        }
    }
    
    /// 從 Keychain 載入私鑰
    private func loadPrivateKeyFromKeychain() throws -> Curve25519.KeyAgreement.PrivateKey? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: keychainService,
            kSecAttrAccount as String: privateKeyTag,
            kSecReturnData as String: kCFBooleanTrue!,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        
        var item: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &item)
        
        if status == errSecItemNotFound {
            return nil
        }
        
        guard status == errSecSuccess else {
            throw CryptoError.keychainError(status)
        }
        
        guard let keyData = item as? Data else {
            throw CryptoError.invalidKeyData
        }
        
        return try Curve25519.KeyAgreement.PrivateKey(rawRepresentation: keyData)
    }
} 