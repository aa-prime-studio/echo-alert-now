import Foundation
import MultipeerConnectivity

// MARK: - Mesh Network Protocol
protocol MeshNetworkProtocol {
    func broadcastMessage(_ data: Data, messageType: MeshMessageType)
    func sendDirectMessage(_ data: Data, to peerID: String, messageType: MeshMessageType)
    func getConnectedPeers() -> [String]
    func getNetworkTopology() -> [String: Set<String>]
}

// MARK: - Message Types
enum MeshMessageType: String, CaseIterable, Codable {
    case signal = "signal"
    case chat = "chat"
    case game = "game"
    case heartbeat = "heartbeat"
    case routingUpdate = "routing_update"
    case keyExchange = "key_exchange"
    case system = "system"
    
    var priority: Int {
        switch self {
        case .signal: return 10
        case .keyExchange: return 9
        case .system: return 8
        case .heartbeat: return 7
        case .routingUpdate: return 6
        case .chat: return 5
        case .game: return 4
        }
    }
}

// MARK: - Mesh Message Structure
struct MeshMessage: Codable {
    let id: String
    let type: MeshMessageType
    let sourceID: String
    let targetID: String? // nil for broadcast
    let data: Data
    let timestamp: Date
    let ttl: Int // Time To Live
    let hopCount: Int
    let routePath: [String] // 記錄路由路徑
    
    init(type: MeshMessageType, sourceID: String, targetID: String? = nil, data: Data, ttl: Int = 10) {
        self.id = UUID().uuidString
        self.type = type
        self.sourceID = sourceID
        self.targetID = targetID
        self.data = data
        self.timestamp = Date()
        self.ttl = ttl
        self.hopCount = 0
        self.routePath = [sourceID]
    }
    
    // 創建轉發副本
    func forwarded(through peerID: String) -> MeshMessage {
        var newMessage = self
        newMessage.hopCount += 1
        newMessage.routePath.append(peerID)
        return newMessage
    }
    
    var isExpired: Bool {
        return ttl <= 0 || Date().timeIntervalSince(timestamp) > 300 // 5 minutes
    }
}

// MARK: - Network Topology
struct NetworkTopology {
    private var connections: [String: Set<String>] = [:]
    private let lock = NSLock()
    
    mutating func addConnection(from: String, to: String) {
        lock.lock()
        defer { lock.unlock() }
        
        connections[from, default: Set()].insert(to)
        connections[to, default: Set()].insert(from)
    }
    
    mutating func removeConnection(from: String, to: String) {
        lock.lock()
        defer { lock.unlock() }
        
        connections[from]?.remove(to)
        connections[to]?.remove(from)
        
        if connections[from]?.isEmpty == true {
            connections.removeValue(forKey: from)
        }
        if connections[to]?.isEmpty == true {
            connections.removeValue(forKey: to)
        }
    }
    
    mutating func removePeer(_ peerID: String) {
        lock.lock()
        defer { lock.unlock() }
        
        if let connectedPeers = connections[peerID] {
            for peer in connectedPeers {
                connections[peer]?.remove(peerID)
                if connections[peer]?.isEmpty == true {
                    connections.removeValue(forKey: peer)
                }
            }
        }
        connections.removeValue(forKey: peerID)
    }
    
    func getConnections() -> [String: Set<String>] {
        lock.lock()
        defer { lock.unlock() }
        return connections
    }
    
    func findRoute(from source: String, to target: String) -> [String]? {
        lock.lock()
        defer { lock.unlock() }
        
        guard source != target else { return [source] }
        
        // BFS 搜尋最短路徑
        var queue: [(String, [String])] = [(source, [source])]
        var visited: Set<String> = [source]
        
        while !queue.isEmpty {
            let (current, path) = queue.removeFirst()
            
            if let neighbors = connections[current] {
                for neighbor in neighbors {
                    if neighbor == target {
                        return path + [neighbor]
                    }
                    
                    if !visited.contains(neighbor) {
                        visited.insert(neighbor)
                        queue.append((neighbor, path + [neighbor]))
                    }
                }
            }
        }
        
        return nil // 無路徑
    }
}

// MARK: - Message Queue
class MessageQueue {
    private var queue: [MeshMessage] = []
    private let lock = NSLock()
    private let maxSize = 1000
    
    func enqueue(_ message: MeshMessage) {
        lock.lock()
        defer { lock.unlock() }
        
        // 按優先級插入
        let insertIndex = queue.firstIndex { $0.type.priority < message.type.priority } ?? queue.count
        queue.insert(message, at: insertIndex)
        
        // 限制佇列大小
        if queue.count > maxSize {
            queue.removeLast()
        }
    }
    
    func dequeue() -> MeshMessage? {
        lock.lock()
        defer { lock.unlock() }
        
        // 移除過期訊息
        queue.removeAll { $0.isExpired }
        
        return queue.isEmpty ? nil : queue.removeFirst()
    }
    
    func clear() {
        lock.lock()
        defer { lock.unlock() }
        queue.removeAll()
    }
    
    var count: Int {
        lock.lock()
        defer { lock.unlock() }
        return queue.count
    }
}

// MARK: - Mesh Manager
@Observable
class MeshManager: MeshNetworkProtocol {
    // MARK: - Properties
    private var networkService: NetworkService
    private var securityService: SecurityService
    private var floodProtection: FloodProtection
    
    private var topology = NetworkTopology()
    private var messageQueue = MessageQueue()
    private var processedMessages: Set<String> = []
    private let processedMessagesLimit = 10000
    
    private var heartbeatTimer: Timer?
    private var queueProcessingTimer: Timer?
    private let heartbeatInterval: TimeInterval = 30.0
    private let queueProcessingInterval: TimeInterval = 0.1
    
    // MARK: - Published State
    @Published var connectedPeers: [String] = []
    @Published var networkStats: NetworkStats = NetworkStats()
    @Published var isActive: Bool = false
    
    // MARK: - Callbacks
    var onMessageReceived: ((Data, MeshMessageType, String) -> Void)?
    var onNetworkTopologyChanged: (([String: Set<String>]) -> Void)?
    
    // MARK: - Initialization
    init(networkService: NetworkService, securityService: SecurityService) {
        self.networkService = networkService
        self.securityService = securityService
        self.floodProtection = FloodProtection()
        
        setupNetworkCallbacks()
        startServices()
        
        print("🕸️ MeshManager initialized")
    }
    
    deinit {
        stopServices()
    }
    
    // MARK: - MeshNetworkProtocol Implementation
    
    func broadcastMessage(_ data: Data, messageType: MeshMessageType) {
        let message = MeshMessage(
            type: messageType,
            sourceID: networkService.myPeerID.displayName,
            data: data
        )
        
        processOutgoingMessage(message)
        
        // 統計
        DispatchQueue.main.async {
            self.networkStats.messagesSent += 1
        }
        
        print("📡 Broadcasting \(messageType.rawValue) message")
    }
    
    /// 廣播訊息（支援優先級和用戶暱稱）
    func broadcast(_ data: Data, priority: MessagePriority, userNickname: String) async throws {
        let message = MeshMessage(
            type: .signal, // Signal 訊息類型
            sourceID: networkService.myPeerID.displayName,
            data: data,
            ttl: priority == .emergency ? 15 : 10 // 緊急訊息有更長的存活時間
        )
        
        processOutgoingMessage(message)
        
        // 統計
        DispatchQueue.main.async {
            self.networkStats.messagesSent += 1
        }
        
        print("📡 Broadcasting priority \(priority.rawValue) message from \(userNickname)")
    }
    
    func sendDirectMessage(_ data: Data, to peerID: String, messageType: MeshMessageType) {
        let message = MeshMessage(
            type: messageType,
            sourceID: networkService.myPeerID.displayName,
            targetID: peerID,
            data: data
        )
        
        processOutgoingMessage(message)
        
        // 統計
        DispatchQueue.main.async {
            self.networkStats.messagesSent += 1
        }
        
        print("📤 Sending \(messageType.rawValue) message to \(peerID)")
    }
    
    func getConnectedPeers() -> [String] {
        return Array(topology.getConnections().keys)
    }
    
    func getNetworkTopology() -> [String: Set<String>] {
        return topology.getConnections()
    }
    
    // MARK: - Private Methods
    
    private func setupNetworkCallbacks() {
        networkService.onDataReceived = { [weak self] data, peerID in
            self?.handleIncomingData(data, from: peerID)
        }
        
        networkService.onPeerConnected = { [weak self] peerID in
            self?.handlePeerConnected(peerID)
        }
        
        networkService.onPeerDisconnected = { [weak self] peerID in
            self?.handlePeerDisconnected(peerID)
        }
    }
    
    private func startServices() {
        isActive = true
        
        // 啟動心跳
        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: heartbeatInterval, repeats: true) { _ in
            self.sendHeartbeat()
        }
        
        // 啟動訊息佇列處理
        queueProcessingTimer = Timer.scheduledTimer(withTimeInterval: queueProcessingInterval, repeats: true) { _ in
            self.processMessageQueue()
        }
        
        print("🚀 MeshManager services started")
    }
    
    private func stopServices() {
        isActive = false
        heartbeatTimer?.invalidate()
        queueProcessingTimer?.invalidate()
        messageQueue.clear()
        
        print("🛑 MeshManager services stopped")
    }
    
    private func handleIncomingData(_ data: Data, from peerID: String) {
        do {
            // 解密數據（如果有會話密鑰）
            let decryptedData: Data
            if securityService.hasSessionKey(for: peerID) {
                decryptedData = try securityService.decrypt(data, from: peerID)
            } else {
                decryptedData = data
            }
            
            // 解析 MeshMessage
            let message = try JSONDecoder().decode(MeshMessage.self, from: decryptedData)
            
            // 防洪和重複檢查
            if floodProtection.shouldBlock(message, from: peerID) {
                print("🚫 Blocked flooding from \(peerID)")
                return
            }
            
            if processedMessages.contains(message.id) {
                print("🔁 Duplicate message ignored: \(message.id)")
                return
            }
            
            // 記錄已處理的訊息
            processedMessages.insert(message.id)
            if processedMessages.count > processedMessagesLimit {
                // 清理舊記錄
                let oldMessages = Array(processedMessages.prefix(processedMessagesLimit / 2))
                for oldID in oldMessages {
                    processedMessages.remove(oldID)
                }
            }
            
            handleMeshMessage(message, from: peerID)
            
            // 統計
            DispatchQueue.main.async {
                self.networkStats.messagesReceived += 1
            }
            
        } catch {
            print("❌ Failed to process incoming data: \(error)")
        }
    }
    
    private func handleMeshMessage(_ message: MeshMessage, from peerID: String) {
        let myID = networkService.myPeerID.displayName
        
        // 檢查是否為目標接收者
        if let targetID = message.targetID {
            if targetID == myID {
                // 直接訊息給我
                onMessageReceived?(message.data, message.type, message.sourceID)
                print("📨 Received direct \(message.type.rawValue) from \(message.sourceID)")
            } else {
                // 需要轉發
                forwardMessage(message, from: peerID)
            }
        } else {
            // 廣播訊息
            if message.sourceID != myID {
                onMessageReceived?(message.data, message.type, message.sourceID)
                forwardMessage(message, from: peerID)
                print("📻 Received broadcast \(message.type.rawValue) from \(message.sourceID)")
            }
        }
        
        // 處理特殊訊息類型
        switch message.type {
        case .heartbeat:
            handleHeartbeat(message, from: peerID)
        case .routingUpdate:
            handleRoutingUpdate(message, from: peerID)
        default:
            break
        }
    }
    
    private func forwardMessage(_ message: MeshMessage, from senderID: String) {
        guard message.ttl > 0 && !message.isExpired else {
            print("⚰️ Message expired, not forwarding")
            return
        }
        
        // 減少 TTL 並更新路徑
        var forwardedMessage = message.forwarded(through: networkService.myPeerID.displayName)
        forwardedMessage.ttl -= 1
        
        // 智能轉發：避免回傳給發送者
        let connectedPeers = networkService.connectedPeers.map { $0.displayName }
        let forwardTargets = connectedPeers.filter { $0 != senderID && !message.routePath.contains($0) }
        
        if !forwardTargets.isEmpty {
            messageQueue.enqueue(forwardedMessage)
            print("🔄 Queued message for forwarding to \(forwardTargets.count) peers")
        }
    }
    
    private func processOutgoingMessage(_ message: MeshMessage) {
        messageQueue.enqueue(message)
    }
    
    private func processMessageQueue() {
        guard let message = messageQueue.dequeue() else { return }
        
        let connectedPeers = networkService.connectedPeers
        
        if let targetID = message.targetID {
            // 直接訊息 - 找到最佳路由
            if let targetPeer = connectedPeers.first(where: { $0.displayName == targetID }) {
                // 直接連接
                sendMessageToPeer(message, peer: targetPeer)
            } else {
                // 需要路由
                routeMessage(message)
            }
        } else {
            // 廣播訊息
            for peer in connectedPeers {
                sendMessageToPeer(message, peer: peer)
            }
        }
    }
    
    private func sendMessageToPeer(_ message: MeshMessage, peer: MCPeerID) {
        do {
            let messageData = try JSONEncoder().encode(message)
            
            // 加密數據（如果有會話密鑰）
            let finalData: Data
            if securityService.hasSessionKey(for: peer.displayName) {
                let encryptedMessage = try securityService.encrypt(messageData, for: peer.displayName)
                finalData = try JSONEncoder().encode(encryptedMessage)
            } else {
                finalData = messageData
            }
            
            Task {
                try await networkService.send(finalData, to: [peer])
            }
            
        } catch {
            print("❌ Failed to send message to \(peer.displayName): \(error)")
        }
    }
    
    private func routeMessage(_ message: MeshMessage) {
        guard let targetID = message.targetID else { return }
        
        if let route = topology.findRoute(from: networkService.myPeerID.displayName, to: targetID) {
            if route.count > 1 {
                let nextHop = route[1]
                if let peer = networkService.connectedPeers.first(where: { $0.displayName == nextHop }) {
                    sendMessageToPeer(message, peer: peer)
                    print("🛤️ Routed message to \(targetID) via \(nextHop)")
                }
            }
        } else {
            print("🚫 No route found to \(targetID)")
        }
    }
    
    private func handlePeerConnected(_ peerID: String) {
        topology.addConnection(from: networkService.myPeerID.displayName, to: peerID)
        updateConnectedPeers()
        sendRoutingUpdate()
        
        // 嘗試密鑰交換
        initiateKeyExchange(with: peerID)
        
        print("🤝 Peer connected: \(peerID)")
    }
    
    private func handlePeerDisconnected(_ peerID: String) {
        topology.removePeer(peerID)
        securityService.removeSessionKey(for: peerID)
        updateConnectedPeers()
        sendRoutingUpdate()
        
        print("👋 Peer disconnected: \(peerID)")
    }
    
    private func updateConnectedPeers() {
        DispatchQueue.main.async {
            self.connectedPeers = self.getConnectedPeers()
            self.onNetworkTopologyChanged?(self.getNetworkTopology())
        }
    }
    
    private func sendHeartbeat() {
        let heartbeatData = "heartbeat".data(using: .utf8) ?? Data()
        broadcastMessage(heartbeatData, messageType: .heartbeat)
    }
    
    private func handleHeartbeat(_ message: MeshMessage, from peerID: String) {
        // 更新拓撲連接
        topology.addConnection(from: message.sourceID, to: peerID)
        updateConnectedPeers()
    }
    
    private func sendRoutingUpdate() {
        do {
            let topologyData = try JSONEncoder().encode(topology.getConnections())
            broadcastMessage(topologyData, messageType: .routingUpdate)
        } catch {
            print("❌ Failed to send routing update: \(error)")
        }
    }
    
    private func handleRoutingUpdate(_ message: MeshMessage, from peerID: String) {
        do {
            let remoteTopology = try JSONDecoder().decode([String: Set<String>].self, from: message.data)
            
            // 合併拓撲信息
            for (node, connections) in remoteTopology {
                for connection in connections {
                    topology.addConnection(from: node, to: connection)
                }
            }
            
            updateConnectedPeers()
            
        } catch {
            print("❌ Failed to process routing update: \(error)")
        }
    }
    
    private func initiateKeyExchange(with peerID: String) {
        do {
            let publicKey = try securityService.getPublicKey()
            sendDirectMessage(publicKey, to: peerID, messageType: .keyExchange)
            print("🔑 Initiated key exchange with \(peerID)")
        } catch {
            print("❌ Failed to initiate key exchange: \(error)")
        }
    }
}

// MARK: - Network Statistics
struct NetworkStats {
    var messagesSent: Int = 0
    var messagesReceived: Int = 0
    var messagesForwarded: Int = 0
    var connectedPeersCount: Int = 0
    var networkDiameter: Int = 0 // 網路直徑（最長路徑）
}

// MARK: - String Extension for Repetition
extension String {
    static func * (left: String, right: Int) -> String {
        return String(repeating: left, count: right)
    }
} 