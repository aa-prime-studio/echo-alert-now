import Foundation
import SwiftUI
import CoreLocation

// MARK: - SignalViewModel
class SignalViewModel: ObservableObject {
    @Published var messages: [SignalMessage] = []
    @Published var deviceName: String = "SignalAir Rescue裝置"
    @Published var connectionStatus: String = "未連線"
    @Published var connectedPeers: [String] = []
    @Published var lastSignalTime: Date?
    
    // Mesh 網路服務
    private let networkService: NetworkService
    private let securityService: SecurityService
    private let meshManager: MeshManager
    private let idManager: TemporaryIDManager
    private let selfDestructManager: SelfDestructManager
    private let floodProtection: FloodProtection
    
    // Settings 參考
    private var settingsViewModel: SettingsViewModel?
    
    // 位置服務
    private let locationManager = CLLocationManager()
    private var currentLocation: CLLocation?
    
    // MARK: - 初始化方法
    
    /// 依賴注入初始化
    init(networkService: NetworkService? = nil,
         securityService: SecurityService? = nil,
         meshManager: MeshManager? = nil,
         idManager: TemporaryIDManager? = nil,
         selfDestructManager: SelfDestructManager? = nil,
         floodProtection: FloodProtection? = nil) {
        
        // 使用注入的服務或創建新的實例
        self.networkService = networkService ?? NetworkService()
        self.securityService = securityService ?? SecurityService()
        self.idManager = idManager ?? TemporaryIDManager()
        self.selfDestructManager = selfDestructManager ?? SelfDestructManager()
        self.floodProtection = floodProtection ?? FloodProtection()
        self.meshManager = meshManager ?? MeshManager()
        
        setupMeshNetworking()
        setupLocationServices()
        setupNotificationObservers()
        
        print("📡 SignalViewModel: 初始化完成，裝置ID: \(self.idManager.deviceID)")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    // MARK: - 公開方法
    
    /// 設定 SettingsViewModel 參考
    func setSettingsViewModel(_ settings: SettingsViewModel) {
        self.settingsViewModel = settings
    }
    
    /// 發送緊急訊號
    func sendSignal(_ type: SignalType) async {
        // 使用 deviceName 如果存在，否則使用設定中的暱稱
        let userNickname = !deviceName.isEmpty ? deviceName : (settingsViewModel?.userNickname ?? "SignalAir Rescue裝置")
        
        let signal = EmergencySignal(
            id: UUID().uuidString,
            type: type,
            location: currentLocationWithNoise(),
            message: generateSignalMessage(for: type),
            deviceID: idManager.deviceID,
            senderNickname: userNickname,
            timestamp: Date()
        )
        
        do {
            // 檢查洪水保護
            let signalData = try JSONEncoder().encode(signal)
            
            if floodProtection.shouldAcceptMessage(
                from: idManager.deviceID,
                content: signalData,
                size: signalData.count,
                priority: .emergency
            ) {
                // 透過 Mesh 網路廣播
                try await meshManager.broadcast(
                    signalData,
                    priority: .emergency,
                    userNickname: userNickname
                )
                
                // 追蹤自毀管理
                selfDestructManager.trackMessage(signal.id, type: .signal, priority: .emergency)
                
                // 更新本地 UI
                let displayMessage = SignalMessage(
                    type: type,
                    deviceName: userNickname,
                    distance: 0, // 自己的訊號
                    direction: nil,
                    timestamp: signal.timestamp
                )
                
                await MainActor.run {
                    messages.insert(displayMessage, at: 0)
                    lastSignalTime = Date()
                }
                
                print("📡 SignalViewModel: 發送緊急訊號成功 - \(type.rawValue) 來自 \(userNickname)")
                
                // 顯示成功訊息（測試用）
                await MainActor.run {
                    // 這裡可以添加成功反饋的 UI 更新
                    print("✅ UI更新: 訊號已發送並顯示在列表中")
                }
                
            } else {
                print("🛡️ SignalViewModel: 訊號被洪水保護阻擋")
                
                // 即使被阻擋也顯示在本地列表（表示使用者已嘗試發送）
                let displayMessage = SignalMessage(
                    type: type,
                    deviceName: "\(userNickname) (限制中)",
                    distance: 0,
                    direction: nil,
                    timestamp: Date()
                )
                
                await MainActor.run {
                    messages.insert(displayMessage, at: 0)
                }
            }
        } catch {
            print("❌ SignalViewModel: 發送訊號失敗 - \(error)")
            
            // 顯示錯誤狀態
            let displayMessage = SignalMessage(
                type: type,
                deviceName: "\(userNickname) (發送失敗)",
                distance: 0,
                direction: nil,
                timestamp: Date()
            )
            
            await MainActor.run {
                messages.insert(displayMessage, at: 0)
            }
        }
    }
    
    /// 更新連線狀態
    func updateConnectionStatus() {
        switch networkService.connectionStatus {
        case .connected:
            connectionStatus = "已連線"
        case .connecting:
            connectionStatus = "連線中"
        case .disconnected:
            connectionStatus = "未連線"
        }
        connectedPeers = networkService.connectedPeers.map { $0.displayName }
    }
    
    /// 手動重新連線
    func reconnect() {
        networkService.startNetworking()
        print("📡 SignalViewModel: 嘗試重新連線")
    }
    
    /// 斷開連線
    func disconnect() async {
        networkService.stopNetworking()
        await MainActor.run {
            connectionStatus = "未連線"
            connectedPeers = []
        }
        print("📡 SignalViewModel: 已斷開連線")
    }
    
    /// 清除訊息
    func clearMessages() {
        messages.removeAll()
        print("📡 SignalViewModel: 清除所有訊號訊息")
    }
    
    // MARK: - 私有方法
    
    /// 設定 Mesh 網路
    private func setupMeshNetworking() {
        // 設定接收處理
        meshManager.setMessageHandler { [weak self] messageData in
            Task { await self?.handleReceivedSignal(messageData) }
        }
        
        // 啟動網路服務
        networkService.startNetworking()
        
        print("📡 SignalViewModel: Mesh 網路設定完成")
    }
    
    /// 設定位置服務
    private func setupLocationServices() {
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        
        // 模擬位置更新（實際應使用 CLLocationManagerDelegate）
        Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in
            self?.updateLocation()
        }
    }
    
    /// 設定通知觀察者
    private func setupNotificationObservers() {
        // 預留給未來的通知處理
    }
    
    /// 更新位置
    private func updateLocation() {
        // 實際實作中應使用真實的 GPS 位置
        // 這裡使用模擬位置
        let randomLat = 25.0330 + Double.random(in: -0.01...0.01) // 台北附近
        let randomLng = 121.5654 + Double.random(in: -0.01...0.01)
        currentLocation = CLLocation(latitude: randomLat, longitude: randomLng)
    }
    
    /// 取得位置（加入雜訊保護隱私）
    private func currentLocationWithNoise() -> LocationData? {
        guard let location = currentLocation else { return nil }
        
        // 加入 50-200 公尺的隨機雜訊
        let noiseLat = Double.random(in: -0.002...0.002) // 約 200m
        let noiseLng = Double.random(in: -0.002...0.002)
        
        return LocationData(
            latitude: location.coordinate.latitude + noiseLat,
            longitude: location.coordinate.longitude + noiseLng,
            accuracy: location.horizontalAccuracy
        )
    }
    
    /// 生成訊號訊息
    private func generateSignalMessage(for type: SignalType) -> String {
        switch type {
        case .safe:
            return "我在這裡，狀況安全"
        case .supplies:
            return "需要物資支援！"
        case .medical:
            return "需要醫療支援！"
        case .danger:
            return "危險警告！請遠離此區域"
        }
    }
    
    /// 處理接收到的訊號
    private func handleReceivedSignal(_ messageData: Data) async {
        do {
            let signal = try JSONDecoder().decode(EmergencySignal.self, from: messageData)
            
            // 計算距離和方向
            let (distance, direction) = calculateDistanceAndDirection(to: signal.location)
            
            let displayMessage = SignalMessage(
                type: signal.type,
                deviceName: signal.senderNickname,
                distance: distance,
                direction: direction,
                timestamp: signal.timestamp
            )
            
            await MainActor.run {
                messages.insert(displayMessage, at: 0)
                
                // 限制訊息數量
                if messages.count > 50 {
                    messages = Array(messages.prefix(50))
                }
            }
            
            print("📡 SignalViewModel: 接收到緊急訊號 - \(signal.type.rawValue) 來自 \(signal.senderNickname)")
            
        } catch {
            print("❌ SignalViewModel: 解析接收訊號失敗 - \(error)")
        }
    }
    
    /// 計算距離和方向
    private func calculateDistanceAndDirection(to location: LocationData?) -> (Double, CompassDirection?) {
        guard let targetLocation = location,
              let currentLoc = currentLocation else {
            return (0, nil)
        }
        
        let target = CLLocation(latitude: targetLocation.latitude, longitude: targetLocation.longitude)
        let distance = currentLoc.distance(from: target)
        
        // 簡化的方向計算
        let latDiff = targetLocation.latitude - currentLoc.coordinate.latitude
        let lngDiff = targetLocation.longitude - currentLoc.coordinate.longitude
        
        let direction: CompassDirection
        if abs(latDiff) > abs(lngDiff) {
            direction = latDiff > 0 ? .north : .south
        } else {
            direction = lngDiff > 0 ? .east : .west
        }
        
        return (distance, direction)
    }
}

// MARK: - 預覽支援

extension SignalViewModel {
    static func preview() -> SignalViewModel {
        let viewModel = SignalViewModel()
        
        // 添加一些範例訊息
        viewModel.messages = [
            SignalMessage(
                type: .safe,
                deviceName: "小明",
                distance: 150.0,
                direction: .north,
                timestamp: Date().addingTimeInterval(-300)
            ),
            SignalMessage(
                type: .medical,
                deviceName: "小華",
                distance: 500.0,
                direction: .east,
                timestamp: Date().addingTimeInterval(-600)
            ),
            SignalMessage(
                type: .danger,
                deviceName: "緊急廣播",
                distance: 1200.0,
                direction: .south,
                timestamp: Date().addingTimeInterval(-900)
            )
        ]
        
        viewModel.connectionStatus = "已連線"
        viewModel.connectedPeers = ["裝置1", "裝置2", "裝置3"]
        
        return viewModel
    }
}
