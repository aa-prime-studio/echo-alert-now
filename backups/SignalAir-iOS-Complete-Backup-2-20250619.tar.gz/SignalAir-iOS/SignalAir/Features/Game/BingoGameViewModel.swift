import Foundation
import SwiftUI

class BingoGameViewModel: ObservableObject {
    // MARK: - Published Properties
    @Published var bingoCard: BingoCard?
    @Published var drawnNumbers: [Int] = []
    @Published var completedLines: Int = 0
    @Published var gameWon: Bool = false
    @Published var roomPlayers: [PlayerState] = []
    @Published var roomChatMessages: [RoomChatMessage] = []
    @Published var newChatMessage: String = ""
    @Published var gameState: GameRoomState.GameState = .waitingForPlayers
    @Published var countdown: Int = 0
    @Published var currentNumber: Int?
    @Published var isHost: Bool = false
    @Published var gameRoomID: String = ""
    @Published var connectionStatus: String = "離線"
    @Published var syncStatus: String = "等待同步"
    @Published var roomID: String = ""
    @Published var isInRoom: Bool = false
    @Published var isGameActive: Bool = false
    
    // MARK: - 遊戲結果回調
    var onGameWon: ((String, Int) -> Void)?
    
    // MARK: - Mesh 網路服務依賴
    private let meshManager: MeshManager
    private let securityService: SecurityService
    private let settingsViewModel: SettingsViewModel
    
    // MARK: - 遊戲管理
    var deviceName: String
    private var playerID: String
    private var hostID: String = ""
    private var gameRoomState: GameRoomState?
    
    // MARK: - 定時器
    private var drawTimer: Timer?
    private var countdownTimer: Timer?
    private var syncTimer: Timer?
    private var heartbeatTimer: Timer?
    private var reconnectTimer: Timer?
    
    // MARK: - 網路狀態
    private var isNetworkActive: Bool = false
    private var lastSyncTime: Date = Date()
    private var reconnectAttempts: Int = 0
    private let maxReconnectAttempts: Int = 5
    
    // MARK: - 語言服務
    var languageService: LanguageService = LanguageService()
    
    // MARK: - 初始化
    init(
        meshManager: MeshManager? = nil,
        securityService: SecurityService? = nil,
        settingsViewModel: SettingsViewModel? = nil
    ) {
        // 服務依賴注入
        let securitySvc = securityService ?? SecurityService()
        
        self.meshManager = meshManager ?? MeshManager()
        self.securityService = securitySvc
        self.settingsViewModel = settingsViewModel ?? SettingsViewModel()
        
        // 初始化玩家資訊
        self.deviceName = self.settingsViewModel.userNickname
        self.playerID = UUID().uuidString
        
        setupMeshNetworking()
        startHeartbeat()
        
        print("🎮 BingoGameViewModel: Mesh 網路版本初始化完成")
    }
    
    deinit {
        cleanup()
    }
    
    // MARK: - Mesh 網路設定
    
    private func setupMeshNetworking() {
        // 啟動 Mesh 網路
        meshManager.startMeshNetwork()
        isNetworkActive = true
        
        // 設定遊戲訊息接收回調
        meshManager.onMessageReceived = { [weak self] meshMessage in
            if meshMessage.type == .game {
                self?.handleIncomingGameMessage(meshMessage)
            }
        }
        
        // 設定 Peer 連線狀態回調
        meshManager.onPeerConnected = { [weak self] peerID in
            DispatchQueue.main.async {
                self?.handlePeerConnected(peerID)
            }
        }
        
        meshManager.onPeerDisconnected = { [weak self] peerID in
            DispatchQueue.main.async {
                self?.handlePeerDisconnected(peerID)
            }
        }
        
        updateConnectionStatus()
    }
    
    // MARK: - 遊戲房間管理
    
    func createGameRoom() {
        gameRoomID = UUID().uuidString
        hostID = playerID
        isHost = true
        
        // 創建初始遊戲狀態
        let initialPlayer = PlayerState(id: playerID, name: deviceName)
        roomPlayers = [initialPlayer]
        
        gameRoomState = GameRoomState(
            roomID: gameRoomID,
            hostID: hostID,
            players: roomPlayers,
            gameState: .waitingForPlayers,
            drawnNumbers: [],
            currentNumber: nil,
            countdown: 0,
            startTime: nil
        )
        
        // 生成 Bingo 卡片
        bingoCard = generateBingoCard()
        
        // 廣播房間創建
        broadcastGameMessage(.roomSync, data: encodeGameRoomState())
        
        addSystemMessage("🏠 已創建遊戲房間: \(gameRoomID.prefix(8))")
        print("🎮 BingoGameViewModel: 創建遊戲房間 \(gameRoomID)")
    }
    
    func joinGameRoom(_ roomID: String) {
        gameRoomID = roomID
        isHost = false
        
        // 請求房間同步
        let requestData = "\(playerID)|\(deviceName)".data(using: .utf8) ?? Data()
        broadcastGameMessage(.reconnectRequest, data: requestData)
        
        // 生成 Bingo 卡片
        bingoCard = generateBingoCard()
        
        addSystemMessage("🔍 正在加入遊戲房間: \(roomID.prefix(8))")
        print("🎮 BingoGameViewModel: 嘗試加入遊戲房間 \(roomID)")
        
        // 開始同步定時器
        startSyncTimer()
    }
    
    func leaveGameRoom() {
        // 廣播離開訊息
        if isNetworkActive {
            let leaveData = "\(playerID)|\(deviceName)".data(using: .utf8) ?? Data()
            broadcastGameMessage(.playerLeft, data: leaveData)
        }
        
        cleanup()
        resetGameState()
        
        addSystemMessage("👋 已離開遊戲房間")
        print("🎮 BingoGameViewModel: 離開遊戲房間")
    }
    
    // MARK: - 遊戲狀態同步
    
    private func handleIncomingGameMessage(_ meshMessage: MeshMessage) {
        do {
            let gameMessage = try JSONDecoder().decode(GameMessage.self, from: meshMessage.data)
            
            // 只處理相同房間的訊息
            guard gameMessage.gameRoomID == gameRoomID || gameMessage.type == .roomSync else { return }
            
            DispatchQueue.main.async {
                self.processGameMessage(gameMessage)
            }
            
        } catch {
            print("❌ BingoGameViewModel: 解析遊戲訊息失敗: \(error)")
        }
    }
    
    private func processGameMessage(_ message: GameMessage) {
        lastSyncTime = Date()
        
        switch message.type {
        case .playerJoined:
            handlePlayerJoined(message)
        case .playerLeft:
            handlePlayerLeft(message)
        case .gameStateUpdate:
            handleGameStateUpdate(message)
        case .numberDrawn:
            handleNumberDrawn(message)
        case .playerProgress:
            handlePlayerProgress(message)
        case .chatMessage:
            handleChatMessage(message)
        case .gameStart:
            handleGameStart(message)
        case .gameEnd:
            handleGameEnd(message)
        case .roomSync:
            handleRoomSync(message)
        case .reconnectRequest:
            handleReconnectRequest(message)
        }
    }
    
    private func handlePlayerJoined(_ message: GameMessage) {
        do {
            let player = try JSONDecoder().decode(PlayerState.self, from: message.data)
            
            // 檢查玩家是否已存在
            if !roomPlayers.contains(where: { $0.id == player.id }) {
                roomPlayers.append(player)
                addSystemMessage("🟢 \(player.name) 加入了遊戲")
                
                // 如果是主機，廣播房間狀態給新玩家
                if isHost {
                    broadcastGameMessage(.roomSync, data: encodeGameRoomState())
                }
            }
        } catch {
            print("❌ BingoGameViewModel: 處理玩家加入失敗: \(error)")
        }
    }
    
    private func handlePlayerLeft(_ message: GameMessage) {
        let components = String(data: message.data, encoding: .utf8)?.split(separator: "|")
        guard let playerIDToRemove = components?.first else { return }
        
        roomPlayers.removeAll { $0.id == String(playerIDToRemove) }
        addSystemMessage("🔴 \(message.senderName) 離開了遊戲")
        
        // 如果主機離開，選擇新主機
        if String(playerIDToRemove) == hostID && !roomPlayers.isEmpty {
            let newHost = roomPlayers.first!
            hostID = newHost.id
            isHost = (newHost.id == playerID)
            addSystemMessage("👑 \(newHost.name) 成為新主機")
        }
    }
    
    private func handleGameStateUpdate(_ message: GameMessage) {
        do {
            let state = try JSONDecoder().decode(GameRoomState.self, from: message.data)
            updateGameState(state)
        } catch {
            print("❌ BingoGameViewModel: 處理遊戲狀態更新失敗: \(error)")
        }
    }
    
    private func handleNumberDrawn(_ message: GameMessage) {
        let numberString = String(data: message.data, encoding: .utf8) ?? ""
        if let number = Int(numberString) {
            if !drawnNumbers.contains(number) {
                drawnNumbers.append(number)
                currentNumber = number
                addSystemMessage("🎯 抽到號碼: \(number)")
            }
        }
    }
    
    private func handlePlayerProgress(_ message: GameMessage) {
        do {
            let player = try JSONDecoder().decode(PlayerState.self, from: message.data)
            
            // 更新玩家進度
            if let index = roomPlayers.firstIndex(where: { $0.id == player.id }) {
                roomPlayers[index] = player
                
                if player.hasWon {
                    addSystemMessage("🏆 \(player.name) 獲勝了！")
                }
            }
        } catch {
            print("❌ BingoGameViewModel: 處理玩家進度失敗: \(error)")
        }
    }
    
    private func handleChatMessage(_ message: GameMessage) {
        let messageText = String(data: message.data, encoding: .utf8) ?? ""
        let chatMessage = RoomChatMessage(
            message: messageText,
            playerName: message.senderName,
            timestamp: message.timestamp.timeIntervalSince1970,
            isOwn: false
        )
        
        roomChatMessages.insert(chatMessage, at: 0)
        if roomChatMessages.count > 50 {
            roomChatMessages = Array(roomChatMessages.prefix(50))
        }
    }
    
    private func handleGameStart(_ message: GameMessage) {
        gameState = .playing
        addSystemMessage("🚀 遊戲開始！")
        
        if isHost {
            startDrawingNumbers()
        }
    }
    
    private func handleGameEnd(_ message: GameMessage) {
        gameState = .finished
        drawTimer?.invalidate()
        countdownTimer?.invalidate()
        
        addSystemMessage("🏁 遊戲結束")
    }
    
    private func handleRoomSync(_ message: GameMessage) {
        do {
            let state = try JSONDecoder().decode(GameRoomState.self, from: message.data)
            
            // 更新房間資訊
            if gameRoomID.isEmpty || gameRoomID == state.roomID {
                gameRoomID = state.roomID
                hostID = state.hostID
                isHost = (hostID == playerID)
                updateGameState(state)
                
                addSystemMessage("🔄 房間狀態已同步")
                syncStatus = "已同步"
            }
        } catch {
            print("❌ BingoGameViewModel: 處理房間同步失敗: \(error)")
        }
    }
    
    private func handleReconnectRequest(_ message: GameMessage) {
        // 只有主機處理重連請求
        guard isHost else { return }
        
        let components = String(data: message.data, encoding: .utf8)?.split(separator: "|")
        guard let requestPlayerID = components?.first,
              let requestPlayerName = components?.last else { return }
        
        // 添加玩家到房間
        let newPlayer = PlayerState(id: String(requestPlayerID), name: String(requestPlayerName))
        if !roomPlayers.contains(where: { $0.id == newPlayer.id }) {
            roomPlayers.append(newPlayer)
        }
        
        // 廣播完整房間狀態
        broadcastGameMessage(.roomSync, data: encodeGameRoomState())
        
        addSystemMessage("🔄 \(requestPlayerName) 重新連線")
    }
    
    // MARK: - 遊戲邏輯
    
    private func startCountdown() {
        guard gameState == .waitingForPlayers, roomPlayers.count >= 2 else { return }
        
        gameState = .countdown
        countdown = 10
        
        addSystemMessage("⏰ 遊戲即將開始，倒數 10 秒")
        
        countdownTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] _ in
            self?.updateCountdown()
        }
        
        // 廣播遊戲狀態
        if isHost {
            broadcastGameMessage(.gameStateUpdate, data: encodeGameRoomState())
        }
    }
    
    private func updateCountdown() {
        countdown -= 1
        
        if countdown <= 0 {
            countdownTimer?.invalidate()
            startGame()
        } else if countdown <= 3 {
            addSystemMessage("⏰ \(countdown)")
        }
        
        // 同步倒數狀態
        if isHost {
            broadcastGameMessage(.gameStateUpdate, data: encodeGameRoomState())
        }
    }
    
    private func startGame() {
        gameState = .playing
        
        addSystemMessage("🎮 遊戲開始！")
        
        // 廣播遊戲開始
        broadcastGameMessage(.gameStart, data: Data())
        
        if isHost {
            startDrawingNumbers()
        }
    }
    
    private func startDrawingNumbers() {
        guard isHost, gameState == .playing else { return }
        
        drawTimer = Timer.scheduledTimer(withTimeInterval: 4.0, repeats: true) { [weak self] _ in
            self?.drawNextNumber()
        }
        
        // 3分鐘後結束遊戲
        DispatchQueue.main.asyncAfter(deadline: .now() + 180) {
            self.endGame()
        }
    }
    
    private func drawNextNumber() {
        let availableNumbers = Array(1...60).filter { !drawnNumbers.contains($0) }
        
        guard !availableNumbers.isEmpty else {
            endGame()
            return
        }
        
        let newNumber = availableNumbers.randomElement()!
        drawnNumbers.append(newNumber)
        currentNumber = newNumber
        
        // 廣播新號碼
        let numberData = String(newNumber).data(using: .utf8) ?? Data()
        broadcastGameMessage(.numberDrawn, data: numberData)
        
        print("🎯 BingoGameViewModel: 抽到號碼 \(newNumber)")
    }
    
    private func endGame() {
        gameState = .finished
        drawTimer?.invalidate()
        
        addSystemMessage("🏁 時間到！遊戲結束")
        
        // 廣播遊戲結束
        broadcastGameMessage(.gameEnd, data: Data())
    }
    
    func markNumber(at index: Int) {
        guard let card = bingoCard, !gameWon, gameState == .playing else { return }
        
        let number = card.numbers[index]
        guard drawnNumbers.contains(number) && !card.marked[index] else { return }
        
        // 標記號碼
        var newCard = card
        newCard.marked[index] = true
        bingoCard = newCard
        
        // 檢查完成的線數
        let lines = checkCompletedLines(newCard.marked)
        completedLines = lines
        
        // 更新玩家狀態
        let hasWon = lines >= 6
        if hasWon && !gameWon {
            gameWon = true
            addSystemMessage("🏆 恭喜您獲勝！")
            
            // 通知外部保存排行榜
            onGameWon?(gameRoomID, lines)
        }
        
        // 更新本地玩家狀態
        if let index = roomPlayers.firstIndex(where: { $0.id == playerID }) {
            var updatedPlayer = roomPlayers[index]
            updatedPlayer = PlayerState(
                id: updatedPlayer.id,
                name: updatedPlayer.name,
                completedLines: lines,
                hasWon: hasWon,
                isConnected: true
            )
            roomPlayers[index] = updatedPlayer
            
            // 廣播玩家進度
            do {
                let playerData = try JSONEncoder().encode(updatedPlayer)
                broadcastGameMessage(.playerProgress, data: playerData)
            } catch {
                print("❌ BingoGameViewModel: 廣播玩家進度失敗: \(error)")
            }
        }
    }
    
    func sendRoomChatMessage() {
        guard !newChatMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        
        let messageText = newChatMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // 本地添加訊息
        let chatMessage = RoomChatMessage(
            message: messageText,
            playerName: deviceName,
            timestamp: Date().timeIntervalSince1970,
            isOwn: true
        )
        
        roomChatMessages.insert(chatMessage, at: 0)
        if roomChatMessages.count > 50 {
            roomChatMessages = Array(roomChatMessages.prefix(50))
        }
        
        // 廣播聊天訊息
        let messageData = messageText.data(using: .utf8) ?? Data()
        broadcastGameMessage(.chatMessage, data: messageData)
        
        newChatMessage = ""
    }
    
    // MARK: - 網路重連機制
    
    func attemptReconnect() {
        guard reconnectAttempts < maxReconnectAttempts else {
            addSystemMessage("❌ 重連失敗，已達最大嘗試次數")
            return
        }
        
        reconnectAttempts += 1
        connectionStatus = "重連中... (\(reconnectAttempts)/\(maxReconnectAttempts))"
        
        // 重啟 Mesh 網路
        meshManager.stopMeshNetwork()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
            self.meshManager.startMeshNetwork()
            
            // 請求房間同步
            if !self.gameRoomID.isEmpty {
                let requestData = "\(self.playerID)|\(self.deviceName)".data(using: .utf8) ?? Data()
                self.broadcastGameMessage(.reconnectRequest, data: requestData)
            }
            
            self.updateConnectionStatus()
        }
        
        addSystemMessage("🔄 正在嘗試重新連線... (\(reconnectAttempts)/\(maxReconnectAttempts))")
    }
    
    // MARK: - 輔助方法
    
    private func generateBingoCard() -> BingoCard {
        var numbers: [Int] = []
        var used = Set<Int>()
        
        // 生成25個不重複的號碼（1-60）
        while numbers.count < 25 {
            let num = Int.random(in: 1...60)
            if !used.contains(num) {
                used.insert(num)
                numbers.append(num)
            }
        }
        
        return BingoCard(numbers: numbers)
    }
    
    private func checkCompletedLines(_ marked: [Bool]) -> Int {
        var lines = 0
        
        // 檢查橫線
        for row in 0..<5 {
            let start = row * 5
            let end = start + 5
            if marked[start..<end].allSatisfy({ $0 }) {
                lines += 1
            }
        }
        
        // 檢查豎線
        for col in 0..<5 {
            let indices = (0..<5).map { row in row * 5 + col }
            if indices.allSatisfy({ marked[$0] }) {
                lines += 1
            }
        }
        
        // 檢查對角線
        let diagonal1 = [0, 6, 12, 18, 24]
        if diagonal1.allSatisfy({ marked[$0] }) {
            lines += 1
        }
        
        let diagonal2 = [4, 8, 12, 16, 20]
        if diagonal2.allSatisfy({ marked[$0] }) {
            lines += 1
        }
        
        return lines
    }
    
    private func broadcastGameMessage(_ type: GameMessageType, data: Data) {
        guard isNetworkActive else { return }
        
        let gameMessage = GameMessage(
            type: type,
            senderID: playerID,
            senderName: deviceName,
            data: data,
            timestamp: Date(),
            gameRoomID: gameRoomID
        )
        
        do {
            let messageData = try JSONEncoder().encode(gameMessage)
            meshManager.broadcastMessage(messageData, messageType: .game)
        } catch {
            print("❌ BingoGameViewModel: 廣播遊戲訊息失敗: \(error)")
        }
    }
    
    private func encodeGameRoomState() -> Data {
        guard let state = gameRoomState else { return Data() }
        
        do {
            return try JSONEncoder().encode(state)
        } catch {
            print("❌ BingoGameViewModel: 編碼房間狀態失敗: \(error)")
            return Data()
        }
    }
    
    private func updateGameState(_ state: GameRoomState) {
        gameRoomState = state
        roomPlayers = state.players
        gameState = state.gameState
        drawnNumbers = state.drawnNumbers
        currentNumber = state.currentNumber
        countdown = state.countdown
    }
    
    private func updateConnectionStatus() {
        let connectedPeers = meshManager.getConnectedPeers()
        
        if connectedPeers.isEmpty {
            connectionStatus = "離線"
            syncStatus = "等待連線"
        } else {
            connectionStatus = "已連線 (\(connectedPeers.count) 個裝置)"
            syncStatus = "網路活躍"
            reconnectAttempts = 0
        }
    }
    
    private func handlePeerConnected(_ peerID: String) {
        updateConnectionStatus()
        
        // 如果是主機，向新連線的 peer 廣播房間狀態
        if isHost && !gameRoomID.isEmpty {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                self.broadcastGameMessage(.roomSync, data: self.encodeGameRoomState())
            }
        }
    }
    
    private func handlePeerDisconnected(_ peerID: String) {
        updateConnectionStatus()
        
        // 標記對應玩家為離線
        roomPlayers = roomPlayers.map { player in
            if player.name == peerID {
                return PlayerState(
                    id: player.id,
                    name: player.name,
                    completedLines: player.completedLines,
                    hasWon: player.hasWon,
                    isConnected: false
                )
            }
            return player
        }
    }
    
    private func addSystemMessage(_ text: String) {
        let systemMessage = RoomChatMessage(
            message: text,
            playerName: "系統",
            timestamp: Date().timeIntervalSince1970,
            isOwn: false
        )
        
        roomChatMessages.insert(systemMessage, at: 0)
        if roomChatMessages.count > 50 {
            roomChatMessages = Array(roomChatMessages.prefix(50))
        }
    }
    
    private func startSyncTimer() {
        syncTimer = Timer.scheduledTimer(withTimeInterval: 10.0, repeats: true) { [weak self] _ in
            self?.checkSyncStatus()
        }
    }
    
    private func startHeartbeat() {
        heartbeatTimer = Timer.scheduledTimer(withTimeInterval: 30.0, repeats: true) { [weak self] _ in
            self?.sendHeartbeat()
        }
    }
    
    private func checkSyncStatus() {
        let timeSinceLastSync = Date().timeIntervalSince(lastSyncTime)
        
        if timeSinceLastSync > 30 && !gameRoomID.isEmpty {
            syncStatus = "同步延遲"
            
            if timeSinceLastSync > 60 {
                syncStatus = "連線不穩定"
                attemptReconnect()
            }
        }
    }
    
    private func sendHeartbeat() {
        guard isNetworkActive, !gameRoomID.isEmpty else { return }
        
        let heartbeatData = "heartbeat".data(using: .utf8) ?? Data()
        broadcastGameMessage(.roomSync, data: heartbeatData)
    }
    
    private func resetGameState() {
        gameState = .waitingForPlayers
        drawnNumbers = []
        currentNumber = nil
        countdown = 0
        gameWon = false
        completedLines = 0
        roomPlayers = []
        roomChatMessages = []
        gameRoomID = ""
        hostID = ""
        isHost = false
        gameRoomState = nil
        reconnectAttempts = 0
    }
    
    private func cleanup() {
        drawTimer?.invalidate()
        countdownTimer?.invalidate()
        syncTimer?.invalidate()
        heartbeatTimer?.invalidate()
        reconnectTimer?.invalidate()
    }
    
    // MARK: - 公開介面方法
    
    func startGameIfReady() {
        guard isHost, gameState == .waitingForPlayers, roomPlayers.count >= 2 else { return }
        startCountdown()
    }
    
    func getConnectionStatusText() -> String {
        return "\(connectionStatus) | \(syncStatus)"
    }
    
    func getGameRoomInfo() -> String {
        if gameRoomID.isEmpty {
            return "未加入房間"
        } else {
            let shortID = String(gameRoomID.prefix(8))
            let role = isHost ? "主機" : "玩家"
            return "房間: \(shortID) (\(role))"
        }
    }
    
    func getPlayersCount() -> String {
        return "\(roomPlayers.count) 位玩家"
    }
    
    /// 加入房間
    func joinRoom(_ room: BingoRoom) {
        self.roomID = "\(room.id)"
        self.isInRoom = true
        self.gameRoomID = self.roomID
        self.isGameActive = true
        
        // 生成 Bingo 卡片
        bingoCard = generateBingoCard()
        
        print("🎯 BingoGameViewModel: 已加入房間 \(room.name)，已生成 Bingo 卡片")
    }
    
    /// 離開房間
    func leaveRoom() {
        self.roomID = ""
        self.gameRoomID = ""
        self.isInRoom = false
        self.isGameActive = false
        resetGameState()
        print("🎯 BingoGameViewModel: 已離開房間")
    }
} 