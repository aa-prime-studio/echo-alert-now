import Foundation
import SwiftUI

// MARK: - Service Container
/// 應用程式服務容器，負責管理所有服務的依賴注入和生命週期
class ServiceContainer: ObservableObject {
    
    // MARK: - Core Services (Singletons)
    static let shared = ServiceContainer()
    
    // MARK: - Network & Security Services
    @Published var networkService: NetworkService
    @Published var securityService: SecurityService
    @Published var meshManager: MeshManager
    
    // MARK: - Business Logic Services
    @Published var languageService: LanguageService
    @Published var nicknameService: NicknameService
    
    // MARK: - Utility Services
    @Published var selfDestructManager: SelfDestructManager
    @Published var temporaryIDManager: TemporaryIDManager
    @Published var floodProtection: FloodProtection
    @Published var settingsViewModel: SettingsViewModel
    
    // MARK: - ViewModels and UI Services
    private var _purchaseService: PurchaseService?
    
    // Lazy initialization for PurchaseService to avoid main actor issues
    var purchaseService: PurchaseService {
        if let service = _purchaseService {
            return service
        }
        let service = PurchaseService()
        _purchaseService = service
        return service
    }
    
    // MARK: - Service Status
    @Published var isInitialized: Bool = false
    @Published var initializationError: String?
    
    // MARK: - Initialization
    public init() {
        print("🚀 ServiceContainer: 開始初始化服務容器...")
        
        // Initialize core infrastructure services
        self.networkService = NetworkService()
        self.securityService = SecurityService()
        
        // Initialize utility services
        self.temporaryIDManager = TemporaryIDManager()
        self.selfDestructManager = SelfDestructManager()
        self.floodProtection = FloodProtection()
        self.meshManager = MeshManager()
        
        // Initialize business logic services
        self.languageService = LanguageService()
        self.nicknameService = NicknameService()
        self.settingsViewModel = SettingsViewModel()
        
        // Configure service relationships
        configureServiceDependencies()
        
        // Start essential services
        Task {
            await initializeServices()
        }
        
        print("✅ ServiceContainer: 服務容器初始化完成")
    }
    
    // MARK: - Service Configuration
    private func configureServiceDependencies() {
        print("🔧 ServiceContainer: 配置服務依賴關係...")
        
        // Configure settings sync with nickname service
        settingsViewModel.userNickname = nicknameService.nickname
        
        // Setup nickname change observation
        nicknameService.objectWillChange.sink { [weak self] in
            DispatchQueue.main.async {
                self?.settingsViewModel.userNickname = self?.nicknameService.nickname ?? "使用者"
            }
        }
        .store(in: &cancellables)
        
        print("✅ ServiceContainer: 服務依賴關係配置完成")
    }
    
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Service Lifecycle
    private func initializeServices() async {
        do {
            print("🚀 ServiceContainer: 開始初始化核心服務...")
            
            // Initialize security service first (essential for all encrypted communication)
            if !securityService.isInitialized {
                try await withTimeout(5.0) {
                    while !self.securityService.isInitialized {
                        try await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
                    }
                }
            }
            
            // Start network services
            networkService.startNetworking()
            
            // Wait for network to be ready
            try await withTimeout(3.0) {
                while self.networkService.connectionStatus == .connecting {
                    try await Task.sleep(nanoseconds: 100_000_000) // 0.1 seconds
                }
            }
            
            // Start mesh network
            meshManager.startMeshNetwork()
            
            await MainActor.run {
                self.isInitialized = true
                self.initializationError = nil
            }
            
            print("✅ ServiceContainer: 所有核心服務初始化完成")
            
        } catch {
            await MainActor.run {
                self.initializationError = "服務初始化失敗: \(error.localizedDescription)"
                print("❌ ServiceContainer: 服務初始化失敗 - \(error)")
            }
        }
    }
    
    // MARK: - Service Access Methods
    
    /// 取得聊天 ViewModel 實例（使用依賴注入）
    func createChatViewModel() -> ChatViewModel {
        return ChatViewModel(
            meshManager: meshManager,
            securityService: securityService,
            selfDestructManager: selfDestructManager,
            settingsViewModel: settingsViewModel
        )
    }
    
    /// 取得信號 ViewModel 實例（使用依賴注入）
    func createSignalViewModel() -> SignalViewModel {
        let viewModel = SignalViewModel(
            networkService: networkService,
            securityService: securityService,
            meshManager: meshManager,
            idManager: temporaryIDManager,
            selfDestructManager: selfDestructManager,
            floodProtection: floodProtection
        )
        viewModel.setSettingsViewModel(settingsViewModel)
        return viewModel
    }
    
    /// 取得遊戲 ViewModel 實例（使用依賴注入）
    func createBingoGameViewModel() -> BingoGameViewModel {
        return BingoGameViewModel(
            meshManager: meshManager,
            securityService: securityService,
            settingsViewModel: settingsViewModel
        )
    }
    
    // MARK: - Service Health Check
    func performHealthCheck() async -> ServiceHealthStatus {
        var status = ServiceHealthStatus()
        
        // Check network service
        status.networkServiceHealthy = (networkService.connectionStatus != .disconnected)
        
        // Check security service
        status.securityServiceHealthy = securityService.isInitialized
        
        // Check mesh manager
        status.meshManagerHealthy = !meshManager.getConnectedPeers().isEmpty || networkService.connectionStatus == .connected
        
        // Overall health
        status.overallHealthy = status.networkServiceHealthy && status.securityServiceHealthy
        
        return status
    }
    
    // MARK: - Service Cleanup
    func shutdown() async {
        print("🛑 ServiceContainer: 開始關閉服務...")
        
        // Stop mesh network
        meshManager.stopMeshNetwork()
        
        // Stop network service
        networkService.stopNetworking()
        
        // Cancel all observations
        cancellables.removeAll()
        
        await MainActor.run {
            self.isInitialized = false
        }
        
        print("✅ ServiceContainer: 服務關閉完成")
    }
}

// MARK: - Service Health Status
struct ServiceHealthStatus {
    var networkServiceHealthy: Bool = false
    var securityServiceHealthy: Bool = false
    var meshManagerHealthy: Bool = false
    var overallHealthy: Bool = false
    
    var healthSummary: String {
        if overallHealthy {
            return "所有服務運行正常"
        } else {
            var issues: [String] = []
            if !networkServiceHealthy { issues.append("網路服務") }
            if !securityServiceHealthy { issues.append("安全服務") }
            if !meshManagerHealthy { issues.append("Mesh 網路") }
            return "服務問題: \(issues.joined(separator: ", "))"
        }
    }
}

// MARK: - Helper Extensions
extension ServiceContainer {
    /// 超時輔助函數
    private func withTimeout<T>(_ timeout: TimeInterval, operation: @escaping () async throws -> T) async throws -> T {
        return try await withThrowingTaskGroup(of: T.self) { group in
            group.addTask {
                return try await operation()
            }
            
            group.addTask {
                try await Task.sleep(nanoseconds: UInt64(timeout * 1_000_000_000))
                throw ServiceError.timeout
            }
            
            let result = try await group.next()!
            group.cancelAll()
            return result
        }
    }
}

// MARK: - Service Errors
enum ServiceError: Error, LocalizedError {
    case timeout
    case initializationFailed(String)
    case serviceUnavailable(String)
    
    var errorDescription: String? {
        switch self {
        case .timeout:
            return "服務初始化超時"
        case .initializationFailed(let message):
            return "服務初始化失敗: \(message)"
        case .serviceUnavailable(let service):
            return "服務不可用: \(service)"
        }
    }
}

// MARK: - Combine Import (Required for observation)
import Combine 