import XCTest
import Foundation
@testable import SignalAir

class NicknameServiceTests: XCTestCase {
    
    var nicknameService: NicknameService!
    var mockUserDefaults: MockUserDefaults!
    
    override func setUp() {
        super.setUp()
        
        // 清除 UserDefaults 中的測試資料
        UserDefaults.standard.removeObject(forKey: "user_nickname")
        UserDefaults.standard.removeObject(forKey: "nickname_remaining_changes")
        
        // 創建測試實例
        nicknameService = NicknameService()
    }
    
    override func tearDown() {
        // 清理測試資料
        UserDefaults.standard.removeObject(forKey: "user_nickname")
        UserDefaults.standard.removeObject(forKey: "nickname_remaining_changes")
        
        nicknameService = nil
        mockUserDefaults = nil
        super.tearDown()
    }
    
    // MARK: - 初始化測試
    
    func testInitialization_FirstTime_ShouldSetDefaultValues() {
        // Given: 第一次使用（UserDefaults 為空）
        UserDefaults.standard.removeObject(forKey: "user_nickname")
        UserDefaults.standard.removeObject(forKey: "nickname_remaining_changes")
        
        // When: 初始化服務
        let service = NicknameService()
        
        // Then: 應該設置預設值
        XCTAssertEqual(service.remainingChanges, 3, "第一次使用應該有3次修改機會")
        XCTAssertFalse(service.nickname.isEmpty, "預設暱稱不應該為空")
        XCTAssertTrue(service.nickname.contains("-"), "預設暱稱應該包含台灣小吃格式")
    }
    
    func testInitialization_ExistingUser_ShouldLoadStoredValues() {
        // Given: 已存在的用戶資料
        UserDefaults.standard.set("測試暱稱", forKey: "user_nickname")
        UserDefaults.standard.set(1, forKey: "nickname_remaining_changes")
        
        // When: 初始化服務
        let service = NicknameService()
        
        // Then: 應該載入儲存的值
        XCTAssertEqual(service.nickname, "測試暱稱")
        XCTAssertEqual(service.remainingChanges, 1)
    }
    
    // MARK: - 更新暱稱測試（正向測試）
    
    func testUpdateNickname_ValidNickname_ShouldSucceed() {
        // Given: 有效的暱稱
        let newNickname = "新暱稱"
        let initialChanges = nicknameService.remainingChanges
        
        // When: 更新暱稱
        let result = nicknameService.updateNickname(newNickname)
        
        // Then: 應該成功更新
        XCTAssertTrue(result, "更新有效暱稱應該成功")
        XCTAssertEqual(nicknameService.nickname, newNickname)
        XCTAssertEqual(nicknameService.remainingChanges, initialChanges - 1)
    }
    
    func testUpdateNickname_SameNickname_ShouldNotDecrementChanges() {
        // Given: 設置初始暱稱
        let initialNickname = "相同暱稱"
        _ = nicknameService.updateNickname(initialNickname)
        let remainingChanges = nicknameService.remainingChanges
        
        // When: 再次設置相同暱稱
        let result = nicknameService.updateNickname(initialNickname)
        
        // Then: 不應該扣除次數
        XCTAssertFalse(result, "設置相同暱稱應該返回false")
        XCTAssertEqual(nicknameService.remainingChanges, remainingChanges, "次數不應該減少")
    }
    
    func testUpdateNickname_WithWhitespace_ShouldTrimAndUpdate() {
        // Given: 包含空白字符的暱稱
        let nicknameWithSpaces = "  測試暱稱  "
        let expectedNickname = "測試暱稱"
        
        // When: 更新暱稱
        let result = nicknameService.updateNickname(nicknameWithSpaces)
        
        // Then: 應該去除空白並更新
        XCTAssertTrue(result)
        XCTAssertEqual(nicknameService.nickname, expectedNickname)
    }
    
    // MARK: - 更新暱稱測試（負向測試）
    
    func testUpdateNickname_EmptyString_ShouldFail() {
        // Given: 空字串
        let emptyNickname = ""
        let initialChanges = nicknameService.remainingChanges
        
        // When: 嘗試更新為空字串
        let result = nicknameService.updateNickname(emptyNickname)
        
        // Then: 應該失敗
        XCTAssertFalse(result, "空字串不應該被接受")
        XCTAssertEqual(nicknameService.remainingChanges, initialChanges, "失敗時次數不應該減少")
    }
    
    func testUpdateNickname_WhitespaceOnly_ShouldFail() {
        // Given: 只有空白字符
        let whitespaceNickname = "   "
        let initialChanges = nicknameService.remainingChanges
        
        // When: 嘗試更新
        let result = nicknameService.updateNickname(whitespaceNickname)
        
        // Then: 應該失敗
        XCTAssertFalse(result, "只有空白字符不應該被接受")
        XCTAssertEqual(nicknameService.remainingChanges, initialChanges, "失敗時次數不應該減少")
    }
    
    func testUpdateNickname_TooLong_ShouldFail() {
        // Given: 超過20字符的暱稱
        let longNickname = "這是一個非常非常非常長的暱稱超過二十個字符"
        let initialChanges = nicknameService.remainingChanges
        
        // When: 嘗試更新
        let result = nicknameService.updateNickname(longNickname)
        
        // Then: 應該失敗
        XCTAssertFalse(result, "超過20字符的暱稱不應該被接受")
        XCTAssertEqual(nicknameService.remainingChanges, initialChanges, "失敗時次數不應該減少")
    }
    
    func testUpdateNickname_NoRemainingChanges_ShouldFail() {
        // Given: 用完所有修改次數
        _ = nicknameService.updateNickname("第一次")
        _ = nicknameService.updateNickname("第二次")
        _ = nicknameService.updateNickname("第三次")
        XCTAssertEqual(nicknameService.remainingChanges, 0)
        
        // When: 嘗試再次更新
        let result = nicknameService.updateNickname("第四次")
        
        // Then: 應該失敗
        XCTAssertFalse(result, "沒有剩餘次數時不應該能更新")
        XCTAssertNotEqual(nicknameService.nickname, "第四次")
    }
    
    // MARK: - 邊界測試
    
    func testUpdateNickname_ExactlyTwentyCharacters_ShouldSucceed() {
        // Given: 恰好20字符的暱稱
        let twentyCharNickname = "12345678901234567890" // 20個字符
        
        // When: 更新暱稱
        let result = nicknameService.updateNickname(twentyCharNickname)
        
        // Then: 應該成功
        XCTAssertTrue(result, "20字符的暱稱應該被接受")
        XCTAssertEqual(nicknameService.nickname, twentyCharNickname)
    }
    
    func testUpdateNickname_OneCharacter_ShouldSucceed() {
        // Given: 單字符暱稱
        let singleCharNickname = "A"
        
        // When: 更新暱稱
        let result = nicknameService.updateNickname(singleCharNickname)
        
        // Then: 應該成功
        XCTAssertTrue(result, "單字符暱稱應該被接受")
        XCTAssertEqual(nicknameService.nickname, singleCharNickname)
    }
    
    func testUpdateNickname_LastRemainingChange_ShouldSucceed() {
        // Given: 只剩最後一次修改機會
        _ = nicknameService.updateNickname("第一次")
        _ = nicknameService.updateNickname("第二次")
        XCTAssertEqual(nicknameService.remainingChanges, 1)
        
        // When: 使用最後一次機會
        let result = nicknameService.updateNickname("最後一次")
        
        // Then: 應該成功並歸零
        XCTAssertTrue(result, "最後一次修改應該成功")
        XCTAssertEqual(nicknameService.nickname, "最後一次")
        XCTAssertEqual(nicknameService.remainingChanges, 0)
    }
    
    // MARK: - 輔助方法測試
    
    func testCanChangeNickname_WithRemainingChanges_ShouldReturnTrue() {
        // Given: 有剩餘修改次數
        XCTAssertGreaterThan(nicknameService.remainingChanges, 0)
        
        // When & Then: 應該返回true
        XCTAssertTrue(nicknameService.canChangeNickname())
    }
    
    func testCanChangeNickname_NoRemainingChanges_ShouldReturnFalse() {
        // Given: 用完所有修改次數
        _ = nicknameService.updateNickname("第一次")
        _ = nicknameService.updateNickname("第二次")
        _ = nicknameService.updateNickname("第三次")
        
        // When & Then: 應該返回false
        XCTAssertFalse(nicknameService.canChangeNickname())
    }
    
    func testGetRemainingChangesText_WithChanges_ShouldReturnCorrectText() {
        // Given: 有剩餘次數
        let remainingChanges = nicknameService.remainingChanges
        
        // When: 獲取文本
        let text = nicknameService.getRemainingChangesText()
        
        // Then: 應該返回正確格式
        XCTAssertEqual(text, "剩餘 \(remainingChanges) 次修改機會")
    }
    
    func testGetRemainingChangesText_NoChanges_ShouldReturnNoChangesText() {
        // Given: 沒有剩餘次數
        _ = nicknameService.updateNickname("第一次")
        _ = nicknameService.updateNickname("第二次")
        _ = nicknameService.updateNickname("第三次")
        
        // When: 獲取文本
        let text = nicknameService.getRemainingChangesText()
        
        // Then: 應該返回無次數文本
        XCTAssertEqual(text, "已用完修改次數")
    }
    
    func testSetNickname_ValidNickname_ShouldSetWithoutDecrementingChanges() {
        // Given: 有效暱稱和初始次數
        let newNickname = "直接設置"
        let initialChanges = nicknameService.remainingChanges
        
        // When: 直接設置暱稱
        nicknameService.setNickname(newNickname)
        
        // Then: 應該設置成功且不減少次數
        XCTAssertEqual(nicknameService.nickname, newNickname)
        XCTAssertEqual(nicknameService.remainingChanges, initialChanges, "直接設置不應該減少次數")
    }
    
    func testSetNickname_EmptyString_ShouldNotChange() {
        // Given: 空字串和初始暱稱
        let initialNickname = nicknameService.nickname
        
        // When: 嘗試設置空字串
        nicknameService.setNickname("")
        
        // Then: 不應該改變
        XCTAssertEqual(nicknameService.nickname, initialNickname)
    }
    
    func testSetNickname_WithWhitespace_ShouldTrimAndSet() {
        // Given: 包含空白的暱稱
        let nicknameWithSpaces = "  直接設置  "
        let expectedNickname = "直接設置"
        
        // When: 設置暱稱
        nicknameService.setNickname(nicknameWithSpaces)
        
        // Then: 應該去除空白
        XCTAssertEqual(nicknameService.nickname, expectedNickname)
    }
    
    // MARK: - 持久化測試
    
    func testPersistence_UpdateNickname_ShouldSaveToUserDefaults() {
        // Given: 新暱稱
        let newNickname = "持久化測試"
        
        // When: 更新暱稱
        _ = nicknameService.updateNickname(newNickname)
        
        // Then: 應該儲存到 UserDefaults
        let savedNickname = UserDefaults.standard.string(forKey: "user_nickname")
        let savedChanges = UserDefaults.standard.integer(forKey: "nickname_remaining_changes")
        
        XCTAssertEqual(savedNickname, newNickname)
        XCTAssertEqual(savedChanges, nicknameService.remainingChanges)
    }
    
    func testPersistence_SetNickname_ShouldSaveToUserDefaults() {
        // Given: 新暱稱
        let newNickname = "直接設置持久化"
        
        // When: 直接設置暱稱
        nicknameService.setNickname(newNickname)
        
        // Then: 應該儲存到 UserDefaults
        let savedNickname = UserDefaults.standard.string(forKey: "user_nickname")
        XCTAssertEqual(savedNickname, newNickname)
    }
    
    // MARK: - 多執行緒安全測試
    
    func testConcurrentUpdates_ShouldMaintainConsistency() {
        // Given: 多個同時更新的期望
        let expectation = XCTestExpectation(description: "Concurrent updates")
        expectation.expectedFulfillmentCount = 5
        
        var results: [Bool] = []
        let queue = DispatchQueue.global(qos: .userInitiated)
        
        // When: 同時執行多個更新
        for i in 0..<5 {
            queue.async {
                let result = self.nicknameService.updateNickname("並發測試\(i)")
                DispatchQueue.main.async {
                    results.append(result)
                    expectation.fulfill()
                }
            }
        }
        
        // Then: 等待所有操作完成並驗證一致性
        wait(for: [expectation], timeout: 5.0)
        
        // 應該只有3個成功（因為只有3次機會）
        let successCount = results.filter { $0 }.count
        XCTAssertLessThanOrEqual(successCount, 3, "成功次數不應該超過允許的修改次數")
        XCTAssertEqual(nicknameService.remainingChanges, 3 - successCount, "剩餘次數應該正確")
    }
    
    // MARK: - 性能測試
    
    func testPerformance_UpdateNickname() {
        measure {
            for i in 0..<1000 {
                _ = nicknameService.updateNickname("性能測試\(i)")
            }
        }
    }
}

// MARK: - Mock Classes

class MockUserDefaults: UserDefaults {
    private var storage: [String: Any] = [:]
    
    override func set(_ value: Any?, forKey defaultName: String) {
        storage[defaultName] = value
    }
    
    override func string(forKey defaultName: String) -> String? {
        return storage[defaultName] as? String
    }
    
    override func integer(forKey defaultName: String) -> Int {
        return storage[defaultName] as? Int ?? 0
    }
    
    override func object(forKey defaultName: String) -> Any? {
        return storage[defaultName]
    }
    
    override func removeObject(forKey defaultName: String) {
        storage.removeValue(forKey: defaultName)
    }
} 