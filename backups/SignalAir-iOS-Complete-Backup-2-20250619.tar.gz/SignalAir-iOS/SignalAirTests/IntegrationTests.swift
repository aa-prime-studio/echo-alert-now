import XCTest
@testable import SignalAir

/// 整合測試 - 測試多個模組之間的協作
class IntegrationTests: XCTestCase {
    
    var serviceContainer: ServiceContainer!
    var chatViewModel: ChatViewModel!
    var signalViewModel: SignalViewModel!
    var gameViewModel: BingoGameViewModel!
    
    override func setUpWithError() throws {
        serviceContainer = ServiceContainer.shared
        
        // 等待服務初始化
        let expectation = XCTestExpectation(description: "Service initialization")
        
        Task {
            // 等待一段時間讓服務初始化
            try await Task.sleep(nanoseconds: 1_000_000_000) // 1 second
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 3.0)
        
        // 創建測試用的 ViewModels
        chatViewModel = serviceContainer.createChatViewModel()
        signalViewModel = serviceContainer.createSignalViewModel()
        gameViewModel = serviceContainer.createBingoGameViewModel()
    }
    
    override func tearDownWithError() throws {
        Task {
            await serviceContainer.shutdown()
        }
        chatViewModel = nil
        signalViewModel = nil
        gameViewModel = nil
        serviceContainer = nil
    }
    
    // MARK: - 聊天系統整合測試
    
    func testChatMessageFlow() async throws {
        // 測試完整的聊天訊息流程
        
        // 1. 設定測試暱稱
        serviceContainer.nicknameService.nickname = "測試用戶A"
        
        // 2. 發送聊天訊息
        let testMessage = "這是整合測試訊息"
        await chatViewModel.sendMessage(testMessage)
        
        // 3. 驗證訊息是否正確處理
        XCTAssertFalse(chatViewModel.messages.isEmpty, "訊息應該被正確發送")
        
        // 4. 檢查訊息內容
        if let sentMessage = chatViewModel.messages.first {
            XCTAssertEqual(sentMessage.content, testMessage)
            XCTAssertEqual(sentMessage.senderNickname, "測試用戶A")
        }
        
        print("✅ 聊天訊息流程測試完成")
    }
    
    func testChatMessageEncryption() async throws {
        // 測試聊天訊息加密功能
        
        let testMessage = "這是加密測試訊息"
        await chatViewModel.sendMessage(testMessage)
        
        // 檢查是否有訊息被發送（加密在背景進行）
        XCTAssertFalse(chatViewModel.messages.isEmpty)
        
        // 驗證安全服務是否被正確使用
        XCTAssertTrue(serviceContainer.securityService.isInitialized)
        
        print("✅ 聊天訊息加密測試完成")
    }
    
    // MARK: - 信號系統整合測試
    
    func testEmergencySignalFlow() async throws {
        // 測試緊急信號完整流程
        
        // 1. 設定測試暱稱
        serviceContainer.nicknameService.nickname = "緊急信號測試者"
        
        // 2. 發送緊急信號
        await signalViewModel.sendSignal(.emergency)
        
        // 3. 等待信號處理
        try await Task.sleep(nanoseconds: 500_000_000) // 0.5 seconds
        
        // 4. 驗證信號是否被正確發送
        XCTAssertFalse(signalViewModel.messages.isEmpty, "緊急信號應該被正確發送")
        
        // 5. 檢查信號內容
        if let signal = signalViewModel.messages.first {
            XCTAssertEqual(signal.type, .emergency)
            XCTAssertEqual(signal.deviceName, "緊急信號測試者")
        }
        
        print("✅ 緊急信號流程測試完成")
    }
    
    func testSignalPriorityHandling() async throws {
        // 測試信號優先級處理
        
        serviceContainer.nicknameService.nickname = "優先級測試者"
        
        // 發送不同優先級的信號
        await signalViewModel.sendSignal(.safe)
        await signalViewModel.sendSignal(.emergency)
        await signalViewModel.sendSignal(.help)
        
        try await Task.sleep(nanoseconds: 500_000_000)
        
        // 驗證所有信號都被處理
        XCTAssertGreaterThanOrEqual(signalViewModel.messages.count, 3)
        
        print("✅ 信號優先級處理測試完成")
    }
    
    // MARK: - 遊戲系統整合測試
    
    func testBingoGameFlow() async throws {
        // 測試 Bingo 遊戲完整流程
        
        // 1. 設定測試暱稱
        serviceContainer.nicknameService.nickname = "遊戲玩家A"
        
        // 2. 創建遊戲房間
        await gameViewModel.createRoom(roomName: "整合測試房間")
        
        // 3. 等待房間創建
        try await Task.sleep(nanoseconds: 500_000_000)
        
        // 4. 驗證遊戲狀態
        XCTAssertEqual(gameViewModel.gameState, .waitingForPlayers)
        XCTAssertEqual(gameViewModel.currentRoom?.name, "整合測試房間")
        
        print("✅ Bingo 遊戲流程測試完成")
    }
    
    func testGamePlayerManagement() async throws {
        // 測試遊戲玩家管理
        
        serviceContainer.nicknameService.nickname = "房主"
        
        // 創建房間
        await gameViewModel.createRoom(roomName: "玩家管理測試")
        
        try await Task.sleep(nanoseconds: 300_000_000)
        
        // 檢查房主設定
        XCTAssertTrue(gameViewModel.isHost)
        XCTAssertNotNil(gameViewModel.currentRoom)
        
        print("✅ 遊戲玩家管理測試完成")
    }
    
    // MARK: - 跨模組整合測試
    
    func testCrossModuleCommunication() async throws {
        // 測試模組間的通訊
        
        serviceContainer.nicknameService.nickname = "跨模組測試者"
        
        // 同時使用聊天和信號功能
        await chatViewModel.sendMessage("測試訊息")
        await signalViewModel.sendSignal(.safe)
        
        try await Task.sleep(nanoseconds: 500_000_000)
        
        // 驗證兩個功能都正常工作
        XCTAssertFalse(chatViewModel.messages.isEmpty)
        XCTAssertFalse(signalViewModel.messages.isEmpty)
        
        // 驗證服務共享
        XCTAssertTrue(serviceContainer.securityService.isInitialized)
        
        print("✅ 跨模組通訊測試完成")
    }
    
    func testServiceSharing() throws {
        // 測試服務共享是否正確
        
        let chatVM1 = serviceContainer.createChatViewModel()
        let chatVM2 = serviceContainer.createChatViewModel()
        let signalVM1 = serviceContainer.createSignalViewModel()
        
        // 所有 ViewModel 都應該正常創建
        XCTAssertNotNil(chatVM1)
        XCTAssertNotNil(chatVM2)
        XCTAssertNotNil(signalVM1)
        
        print("✅ 服務共享測試完成")
    }
    
    // MARK: - 網路整合測試
    
    func testNetworkServiceIntegration() async throws {
        // 測試網路服務整合
        
        let healthStatus = await serviceContainer.performHealthCheck()
        
        // 驗證健康狀態結構
        XCTAssertNotNil(healthStatus.healthSummary)
        
        // 在模擬器環境中，網路服務可能不會完全啟動
        // 但應該能正常處理狀態查詢
        print("📊 Network Integration Status: \(healthStatus.healthSummary)")
        
        XCTAssertTrue(true, "網路服務整合測試完成")
    }
    
    // MARK: - 錯誤處理整合測試
    
    func testErrorHandlingAcrossModules() async throws {
        // 測試跨模組錯誤處理
        
        // 嘗試在沒有網路的情況下發送訊息
        await chatViewModel.sendMessage("")  // 空訊息
        
        // 系統應該優雅處理錯誤，不應該崩潰
        XCTAssertTrue(true, "錯誤處理測試完成")
        
        print("✅ 跨模組錯誤處理測試完成")
    }
    
    // MARK: - 效能整合測試
    
    func testMultiModulePerformance() throws {
        // 測試多模組同時使用的效能
        
        measure {
            let chatVM = serviceContainer.createChatViewModel()
            let signalVM = serviceContainer.createSignalViewModel()
            let gameVM = serviceContainer.createBingoGameViewModel()
            
            // 模擬同時使用多個功能
            Task {
                await chatVM.sendMessage("效能測試")
                await signalVM.sendSignal(.safe)
                await gameVM.createRoom(roomName: "效能測試房間")
            }
        }
        
        print("✅ 多模組效能測試完成")
    }
    
    // MARK: - 資料一致性測試
    
    func testDataConsistencyAcrossViewModels() async throws {
        // 測試多個 ViewModel 之間的資料一致性
        
        // 更改暱稱
        serviceContainer.nicknameService.nickname = "一致性測試者"
        
        // 等待同步
        try await Task.sleep(nanoseconds: 300_000_000)
        
        // 創建新的 ViewModel，應該使用更新後的暱稱
        let newChatVM = serviceContainer.createChatViewModel()
        let newSignalVM = serviceContainer.createSignalViewModel()
        
        XCTAssertNotNil(newChatVM)
        XCTAssertNotNil(newSignalVM)
        
        print("✅ 資料一致性測試完成")
    }
} 