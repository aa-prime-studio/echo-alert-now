import XCTest
import Combine
@testable import SignalAir

/// 全面的 LanguageService 單元測試
/// 
/// 測試範圍：
/// - 初始化和語言載入
/// - 語言切換功能
/// - 翻譯功能
/// - UserDefaults 持久化
/// - 觀察者模式 (@Published)
/// - 邊界條件和錯誤處理
/// - 效能測試
/// 
/// 覆蓋率目標：90%+
final class LanguageServiceTests: XCTestCase {
    
    // MARK: - Test Properties
    
    private var languageService: LanguageService!
    private var mockUserDefaults: MockUserDefaults!
    private var cancellables: Set<AnyCancellable>!
    
    // MARK: - Test Lifecycle
    
    override func setUp() {
        super.setUp()
        mockUserDefaults = MockUserDefaults()
        cancellables = Set<AnyCancellable>()
        
        // 使用 mock UserDefaults 創建 LanguageService
        languageService = LanguageService()
        
        // 使用反射替換 UserDefaults（模擬依賴注入）
        let mirror = Mirror(reflecting: languageService)
        if let userDefaultsChild = mirror.children.first(where: { $0.label == "userDefaults" }) {
            // 在實際應用中，應該通過依賴注入來處理這個問題
            // 這裡我們直接測試現有的實作
        }
    }
    
    override func tearDown() {
        cancellables?.removeAll()
        cancellables = nil
        languageService = nil
        mockUserDefaults = nil
        super.tearDown()
    }
    
    // MARK: - Initialization Tests
    
    /// 測試：預設初始化應該設定為中文
    func testInitialization_ShouldDefaultToChinese() {
        // Given & When
        let service = LanguageService()
        
        // Then
        XCTAssertEqual(service.currentLanguage, .chinese, "預設語言應該是中文")
    }
    
    /// 測試：從 UserDefaults 載入已儲存的語言設定
    func testInitialization_ShouldLoadSavedLanguage() {
        // Given
        UserDefaults.standard.set("en", forKey: "selectedLanguage")
        
        // When
        let service = LanguageService()
        
        // Then
        XCTAssertEqual(service.currentLanguage, .english, "應該載入已儲存的英文設定")
        
        // Cleanup
        UserDefaults.standard.removeObject(forKey: "selectedLanguage")
    }
    
    /// 測試：載入無效的語言設定時應該回退到中文
    func testInitialization_WithInvalidLanguage_ShouldFallbackToChinese() {
        // Given
        UserDefaults.standard.set("invalid_language", forKey: "selectedLanguage")
        
        // When
        let service = LanguageService()
        
        // Then
        XCTAssertEqual(service.currentLanguage, .chinese, "無效語言設定應該回退到中文")
        
        // Cleanup
        UserDefaults.standard.removeObject(forKey: "selectedLanguage")
    }
    
    // MARK: - Language Setting Tests
    
    /// 測試：設定語言為英文
    func testSetLanguage_ToEnglish_ShouldUpdateCurrentLanguage() {
        // Given
        languageService.currentLanguage = .chinese
        
        // When
        languageService.setLanguage(.english)
        
        // Then
        XCTAssertEqual(languageService.currentLanguage, .english, "語言應該更新為英文")
    }
    
    /// 測試：設定語言為中文
    func testSetLanguage_ToChinese_ShouldUpdateCurrentLanguage() {
        // Given
        languageService.currentLanguage = .english
        
        // When
        languageService.setLanguage(.chinese)
        
        // Then
        XCTAssertEqual(languageService.currentLanguage, .chinese, "語言應該更新為中文")
    }
    
    /// 測試：設定語言應該觸發 @Published 更新
    func testSetLanguage_ShouldTriggerPublishedUpdate() {
        // Given
        let expectation = XCTestExpectation(description: "語言變更應該觸發發布更新")
        var receivedLanguage: LanguageService.Language?
        
        languageService.$currentLanguage
            .dropFirst() // 忽略初始值
            .sink { language in
                receivedLanguage = language
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        languageService.setLanguage(.english)
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertEqual(receivedLanguage, .english, "應該收到英文語言更新")
    }
    
    /// 測試：設定相同語言不應該觸發不必要的更新
    func testSetLanguage_SameLanguage_ShouldNotTriggerUnnecessaryUpdate() {
        // Given
        languageService.currentLanguage = .chinese
        let expectation = XCTestExpectation(description: "相同語言不應該觸發更新")
        expectation.isInverted = true
        
        languageService.$currentLanguage
            .dropFirst()
            .sink { _ in
                expectation.fulfill()
            }
            .store(in: &cancellables)
        
        // When
        languageService.setLanguage(.chinese)
        
        // Then
        wait(for: [expectation], timeout: 0.5)
        XCTAssertEqual(languageService.currentLanguage, .chinese, "語言應該保持為中文")
    }
    
    // MARK: - UserDefaults Persistence Tests
    
    /// 測試：設定語言應該持久化到 UserDefaults
    func testSetLanguage_ShouldPersistToUserDefaults() {
        // Given & When
        languageService.setLanguage(.english)
        
        // Then
        let savedLanguage = UserDefaults.standard.string(forKey: "selectedLanguage")
        XCTAssertEqual(savedLanguage, "en", "英文設定應該儲存到 UserDefaults")
        
        // Cleanup
        UserDefaults.standard.removeObject(forKey: "selectedLanguage")
    }
    
    /// 測試：多次設定語言應該正確持久化
    func testSetLanguage_MultipleTimes_ShouldPersistCorrectly() {
        // Given & When
        languageService.setLanguage(.english)
        languageService.setLanguage(.chinese)
        languageService.setLanguage(.english)
        
        // Then
        let savedLanguage = UserDefaults.standard.string(forKey: "selectedLanguage")
        XCTAssertEqual(savedLanguage, "en", "最後設定的英文應該儲存到 UserDefaults")
        XCTAssertEqual(languageService.currentLanguage, .english, "當前語言應該是英文")
        
        // Cleanup
        UserDefaults.standard.removeObject(forKey: "selectedLanguage")
    }
    
    // MARK: - Translation Tests
    
    /// 測試：中文翻譯功能
    func testTranslation_Chinese_ShouldReturnCorrectTranslation() {
        // Given
        languageService.setLanguage(.chinese)
        
        // When & Then
        XCTAssertEqual(languageService.t("settings"), "設定", "中文設定翻譯應該正確")
        XCTAssertEqual(languageService.t("language"), "語言", "中文語言翻譯應該正確")
        XCTAssertEqual(languageService.t("signals"), "訊號", "中文訊號翻譯應該正確")
        XCTAssertEqual(languageService.t("chat"), "聊天室", "中文聊天室翻譯應該正確")
        XCTAssertEqual(languageService.t("games"), "遊戲", "中文遊戲翻譯應該正確")
    }
    
    /// 測試：英文翻譯功能
    func testTranslation_English_ShouldReturnCorrectTranslation() {
        // Given
        languageService.setLanguage(.english)
        
        // When & Then
        XCTAssertEqual(languageService.t("settings"), "Settings", "英文設定翻譯應該正確")
        XCTAssertEqual(languageService.t("language"), "Language", "英文語言翻譯應該正確")
        XCTAssertEqual(languageService.t("signals"), "Signals", "英文訊號翻譯應該正確")
        XCTAssertEqual(languageService.t("chat"), "Chat", "英文聊天翻譯應該正確")
        XCTAssertEqual(languageService.t("games"), "Games", "英文遊戲翻譯應該正確")
    }
    
    /// 測試：複雜翻譯內容
    func testTranslation_ComplexContent_ShouldReturnCorrectTranslation() {
        // Given
        languageService.setLanguage(.chinese)
        
        // When & Then
        XCTAssertEqual(languageService.t("connected_status"), "已連線 - 可發送和接收訊號", "複雜中文翻譯應該正確")
        XCTAssertEqual(languageService.t("signals_will_show"), "當附近有人發送訊號時，會顯示在這裡", "長文本中文翻譯應該正確")
        
        // Switch to English
        languageService.setLanguage(.english)
        XCTAssertEqual(languageService.t("connected_status"), "Connected - Can send and receive signals", "複雜英文翻譯應該正確")
        XCTAssertEqual(languageService.t("signals_will_show"), "When someone nearby sends a signal, it will appear here", "長文本英文翻譯應該正確")
    }
    
    /// 測試：不存在的翻譯鍵應該回傳原始鍵值
    func testTranslation_NonExistentKey_ShouldReturnOriginalKey() {
        // Given
        languageService.setLanguage(.chinese)
        
        // When & Then
        XCTAssertEqual(languageService.t("non_existent_key"), "non_existent_key", "不存在的鍵應該回傳原始值")
        XCTAssertEqual(languageService.t(""), "", "空字串應該回傳空字串")
        XCTAssertEqual(languageService.t("random_key_12345"), "random_key_12345", "隨機鍵應該回傳原始值")
    }
    
    /// 測試：空字串和特殊字元翻譯
    func testTranslation_EdgeCases_ShouldHandleCorrectly() {
        // Given
        languageService.setLanguage(.chinese)
        
        // When & Then
        XCTAssertEqual(languageService.t(""), "", "空字串應該回傳空字串")
        XCTAssertEqual(languageService.t(" "), " ", "空格應該回傳空格")
        XCTAssertEqual(languageService.t("123"), "123", "數字應該回傳原值")
        XCTAssertEqual(languageService.t("@#$%"), "@#$%", "特殊字元應該回傳原值")
    }
    
    // MARK: - Language Enum Tests
    
    /// 測試：語言列舉的顯示名稱
    func testLanguageEnum_DisplayNames_ShouldBeCorrect() {
        // When & Then
        XCTAssertEqual(LanguageService.Language.chinese.displayName, "繁體中文", "中文顯示名稱應該正確")
        XCTAssertEqual(LanguageService.Language.english.displayName, "English", "英文顯示名稱應該正確")
    }
    
    /// 測試：語言列舉的原始值
    func testLanguageEnum_RawValues_ShouldBeCorrect() {
        // When & Then
        XCTAssertEqual(LanguageService.Language.chinese.rawValue, "zh", "中文原始值應該是 zh")
        XCTAssertEqual(LanguageService.Language.english.rawValue, "en", "英文原始值應該是 en")
    }
    
    /// 測試：語言列舉的 CaseIterable 功能
    func testLanguageEnum_CaseIterable_ShouldContainAllCases() {
        // When
        let allCases = LanguageService.Language.allCases
        
        // Then
        XCTAssertEqual(allCases.count, 2, "應該有兩種語言")
        XCTAssertTrue(allCases.contains(.chinese), "應該包含中文")
        XCTAssertTrue(allCases.contains(.english), "應該包含英文")
    }
    
    /// 測試：從原始值創建語言列舉
    func testLanguageEnum_InitFromRawValue_ShouldWork() {
        // When & Then
        XCTAssertEqual(LanguageService.Language(rawValue: "zh"), .chinese, "zh 應該對應中文")
        XCTAssertEqual(LanguageService.Language(rawValue: "en"), .english, "en 應該對應英文")
        XCTAssertNil(LanguageService.Language(rawValue: "fr"), "無效原始值應該回傳 nil")
        XCTAssertNil(LanguageService.Language(rawValue: ""), "空字串應該回傳 nil")
    }
    
    // MARK: - Integration Tests
    
    /// 測試：完整的語言切換流程
    func testLanguageSwitching_FullFlow_ShouldWorkCorrectly() {
        // Given
        let expectation = XCTestExpectation(description: "完整語言切換流程")
        var updateCount = 0
        
        languageService.$currentLanguage
            .dropFirst()
            .sink { language in
                updateCount += 1
                if updateCount == 2 {
                    expectation.fulfill()
                }
            }
            .store(in: &cancellables)
        
        // When
        languageService.setLanguage(.english)
        XCTAssertEqual(languageService.t("settings"), "Settings", "切換到英文後翻譯應該正確")
        
        languageService.setLanguage(.chinese)
        XCTAssertEqual(languageService.t("settings"), "設定", "切換回中文後翻譯應該正確")
        
        // Then
        wait(for: [expectation], timeout: 1.0)
        XCTAssertEqual(updateCount, 2, "應該收到兩次語言更新")
    }
    
    /// 測試：並發語言切換
    func testLanguageSwitching_Concurrent_ShouldBeThreadSafe() {
        // Given
        let expectation = XCTestExpectation(description: "並發語言切換")
        let queue = DispatchQueue.global(qos: .userInitiated)
        
        // When
        DispatchQueue.concurrentPerform(iterations: 100) { index in
            let language: LanguageService.Language = index % 2 == 0 ? .chinese : .english
            languageService.setLanguage(language)
        }
        
        // Then
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            // 驗證最終狀態是一致的
            let finalLanguage = self.languageService.currentLanguage
            XCTAssertTrue(finalLanguage == .chinese || finalLanguage == .english, "最終語言應該是有效的")
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 2.0)
    }
    
    // MARK: - Performance Tests
    
    /// 測試：翻譯效能
    func testTranslation_Performance_ShouldBeFast() {
        // Given
        languageService.setLanguage(.chinese)
        let keys = ["settings", "language", "signals", "chat", "games", "nickname", "version"]
        
        // When & Then
        measure {
            for _ in 0..<1000 {
                for key in keys {
                    _ = languageService.t(key)
                }
            }
        }
    }
    
    /// 測試：語言切換效能
    func testLanguageSwitching_Performance_ShouldBeFast() {
        // When & Then
        measure {
            for _ in 0..<100 {
                languageService.setLanguage(.english)
                languageService.setLanguage(.chinese)
            }
        }
    }
    
    // MARK: - Memory Tests
    
    /// 測試：記憶體洩漏檢查
    func testMemoryLeak_ShouldNotLeakMemory() {
        // Given
        weak var weakService: LanguageService?
        
        // When
        autoreleasepool {
            let service = LanguageService()
            weakService = service
            service.setLanguage(.english)
            _ = service.t("settings")
        }
        
        // Then
        XCTAssertNil(weakService, "LanguageService 應該被正確釋放")
    }
    
    /// 測試：觀察者記憶體洩漏檢查
    func testObserverMemoryLeak_ShouldNotLeakMemory() {
        // Given
        weak var weakService: LanguageService?
        var cancellable: AnyCancellable?
        
        // When
        autoreleasepool {
            let service = LanguageService()
            weakService = service
            
            cancellable = service.$currentLanguage.sink { _ in }
        }
        
        // 取消訂閱
        cancellable?.cancel()
        cancellable = nil
        
        // Then
        XCTAssertNil(weakService, "有觀察者的 LanguageService 應該被正確釋放")
    }
    
    // MARK: - Boundary Tests
    
    /// 測試：極大量翻譯鍵測試
    func testTranslation_LargeNumberOfKeys_ShouldHandleCorrectly() {
        // Given
        languageService.setLanguage(.chinese)
        
        // When & Then
        for i in 0..<10000 {
            let key = "test_key_\(i)"
            let result = languageService.t(key)
            XCTAssertEqual(result, key, "大量翻譯鍵應該正確處理")
        }
    }
    
    /// 測試：極長翻譯鍵測試
    func testTranslation_VeryLongKey_ShouldHandleCorrectly() {
        // Given
        languageService.setLanguage(.chinese)
        let longKey = String(repeating: "a", count: 10000)
        
        // When
        let result = languageService.t(longKey)
        
        // Then
        XCTAssertEqual(result, longKey, "極長翻譯鍵應該正確處理")
    }
}

// MARK: - Mock Classes

/// Mock UserDefaults for testing
class MockUserDefaults: UserDefaults {
    private var storage: [String: Any] = [:]
    
    override func set(_ value: Any?, forKey defaultName: String) {
        storage[defaultName] = value
    }
    
    override func string(forKey defaultName: String) -> String? {
        return storage[defaultName] as? String
    }
    
    override func removeObject(forKey defaultName: String) {
        storage.removeValue(forKey: defaultName)
    }
    
    func clearAll() {
        storage.removeAll()
    }
} 